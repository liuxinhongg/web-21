var express = require('express');
var router = express.Router();
let sql = require("./mysql.js")
// 加密
let crypto = require("crypto")
let PWD_SALT = "web_there";
function md5(s) {
  return crypto.createHash("md5").update(String(s)).digest('hex')
}
// 生成token
let jswtoken = require("jsonwebtoken");
let ptrrivate_key = "yukuan";
let time = 60 * 6;

/* GET home page. */
router.get('/', function (req, res, next) {
  // res.render('index', { title: 'Express' });
  res.send({
    name: "zhou",
    nick: "bapi"
  })
});
// 注册
router.post('/register', function (req, res, next) {
  let user = req.body;
  if (user.username && user.password && user.xuehao) {
    let sqlsearch = `select * from user where username = ?`;
    sql.query(sqlsearch, [user.username], result => {
      console.log(result);
      if (result.length) {

        res.send({
          msg: "用户名已存在",
          code: 0
        })
      } else {
        let sqladd = 'insert into user(username,password,xuehao) values(?,?,?)';
        user.password = md5(`${user.password}${PWD_SALT}`)
        let sqlparams = [user.username, user.password, user.xuehao];
        sql.query(sqladd, sqlparams, function (result) {
          res.send({
            msg: "注册成功",
            code: 1
          })
        })
      }
    })
  } else {
    res.send({
      msg: "输入信息不能为空",
      code: -1
    })
  }
});
// 登录
router.post("/login", (req, res, next) => {
  let login = req.body;
  if (login.username && login.password) {
    sql.query(`select * from user where username = ?`, [login.username], result => {
      if (result.length) {
        login.password = md5(`${login.password}${PWD_SALT}`)
        if (result[0].password === login.password) {
          let token = jswtoken.sign(login, ptrrivate_key, { expiresIn: time });
          res.send({
            msg: "登录成功",
            token: token,
            code: 1
          })
        } else {
          res.send({
            msg: "密码错误",
            code: 2
          })
        }
      } else {
        res.send({
          msg: "用户不存在",
          code: 0
        })
      }
    })
  } else {
    res.send({
      msg: "用户名或密码信息不能为空",
      code: -1
    })
  }
})
//查询用户信息
router.get("/userinfo", (req, res, next) => {
  console.log(req.query);
  let user = req.query.username;
  res.header("Access-Control-Allow-Origin", "*");
  if (user === "" || user === undefined) {
    res.send({
      msg: "用户不能为空",
      code: 0
    })
  }
  sql.query("select username,xuehao from user where username =?", [user], result => {
    if (result.length) {
      res.send({
        msg: "查询成功",
        code: 1,
        data: result
      })
    } else {
      res.send({
        msg: "用户名不存在",
        code: -1,
      })
    }
  })
})
router.get("/allsearch", (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  sql.query("select * from user", [], result => {
    res.send({
      code: 1,
      data: result
    })
  })
})
// x修改用户信息
router.get("/findid", (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  sql.query("select * from user", [], result => {
    res.send({
      msg: "success",
      code: 1,
      data: result,
    })
  })
})
router.get("/updata", (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  let updata = req.query;
  sql.query("update user set username=?,password=?,xuehao=?where ID=?"[updata.username, updata.password, updata.xuehao, updata.ID], result => {
    res, send({
      msg: "更新成功",
      code: 1
    })
  })
})
module.exports = router;
var express = require("express");
var router = express.Router();
var mysql = require("./mysql.js")
// GET users listing
router.get('/goods', function (req, res, next) {//轮播图
    let data = req.query;
    let sqladd = "insert into banner(name.img) value(?,?)";
    let sqlpram = [data.name, data.img];
    mysql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1
        })
    })
});
//获取轮播图
router.get('/banner', function (req, res, next) {
    let sqladd = "select * from banner";
    let sqlpram = [];
    mysql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1,
            data:result
        })
    })
});

// 添加导航
router.get('/vive', function (req, res, next) {
    let data = req.query;
    let sqladd = "insert into sort(name ,title,img) value(?,?,?)";
    let sqlpram = [data.name, data.title, data.img];
    mysql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1
        })
    })
})
//获取分类
router.get('/sort', function (req, res, next) {
    let sqladd = "select * from sort";
    let sqlpram = [];
    mysql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1,
            data:result
        })
    })
});
// 添加分类
router.get('/per', function (req, res, next) {
    let data = req.query;
    let sqladd = "insert into sortSearch('name','sort','img','data','price','shop_name','desc','provcity') value(?,?,?,?,?,?,?,?)";
    let sqlpram = [data.name, data.sort, data.img, data.data, data.price, data.shop_name, data.desc, data.provcity];
    mysql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1
        })
    })
})
module.exports = router;
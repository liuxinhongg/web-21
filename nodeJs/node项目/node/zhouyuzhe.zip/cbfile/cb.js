var mysql = require("./mysql")
var { md5 } = require("../config/method.js")
var sql = require("../config/sql.js")
var { PWD_SALT } = require("../config/other")
var jquery = require("../routes/jQuery1.12.4")
var other = require("../config/other.js")
var goods = require("../routes/goods.js")
class Users {
    zhuce(req, res, next) {
        let users = req.body;//上面的缩写
        console.log(users)
        if (users.username && users.password && users.email && users.phone && users.nick) {//注册
            // let sqlsearch = "select * from web23 where username = ?";
            mysql.query(sql.Usersert, [users.username], result => {
                console.log(result);
                if (result.length) {
                    res.send({
                        msg: "用户名已存在",
                        code: 0
                    })
                } else {
                    // let sqladd = "insert into web23(username,password,email,phone,nick) values(?,?,?,?,?)";
                    users.password = md5(`${users.password}${PWD_SALT}`);//md5 转码
                    let sqlparams = [users.username, users.password, users.email, users.phone, users.nick];
                    mysql.query(sql.Useradd, sqlparams, (result) => {
                        res.send({
                            msg: "注册成功",
                            code: 1
                        })
                    })
                }
            })
        } else {
            res.send({
                msg: "输入信息不能为空",
                code: -1
            })
        }
    }

    zhuce(req, res, next) {//更新
        res.header("Access-Control-Allow-Origin", "*");
        let updata = req.query;
        mysql.query(sql.UserUPdata, [updata.username, updata.email, updata.phone, updata.nick, updata.id], result => {
            res.send({
                msg: "更新成功",
                code: 1
            })
        })


    }
    xiugai(req, res, next) {//修改
        res.header("Access-Control-Allow-Origin", "*");//解决跨域问题
        mysql.query(sql.Useramend, [req.query.id], result => {
            res.send({
                msg: "修改成功",
                code: 1,
                data: result
            })
        })
    }

}
module.exports = new Users()
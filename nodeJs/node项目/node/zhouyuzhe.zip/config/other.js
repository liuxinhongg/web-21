module.exports = {
    PWD_SALT : "user",
}
var obj = {//sql语句
    Useradd : `insert into user(username,password,xuehao) values(?,?,?)`,//插入/增加
    Usersert:`select * from user where username = ?`,//查询所有
    UserUPdata:`update user set username=?,email=?,phone=?,nick=? where id=?`,//更新
    Useramend:`select username,email,phone,nick from web23 where id =?`//修改
}
module.exports = obj
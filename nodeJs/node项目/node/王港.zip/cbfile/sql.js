let mysql = require("mysql")
let pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'wg151279',
    port: '3306',
    database: 'first'
})
exports.query = function(sql,arr,callback){
	pool.getConnection(function(err,connection){
		if(err) {
			throw  new Error();
			return;
		}
		connection.query(sql,arr,function(error,result){
			connection.release();
			if(error) throw error;
			callback && callback(result)
		})
	})
}

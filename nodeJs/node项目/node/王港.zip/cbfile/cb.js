let sql = require("./sql");
let sqlConfig = require("../config/sql.js")
let { md5 } = require("../config/method.js");
let jswtoken = require("jsonwebtoken");
let { PWD_SALT, PRIVATE_KEY, TIME } = require("../config/otherConfig.js")
class UserCb {
	zhuce(req, res, next) {
		let user = req.body;
		if (user.username && user.password && user.age && user.phone) {
			sql.query(sqlConfig.userSearch, [user.username], result => {
				if (result.length) {
					res.send({
						msg: "用户名已存在",
						code: 0
					})
				} else {
					user.password = md5(`${user.password}${PWD_SALT}`)
					let sqlparams = [user.username, user.password, user.age, user.phone];
					sql.query(sqlConfig.userInsert, sqlparams, function (result) {
						res.send({
							msg: "注册成功",
							code: 1
						})
					})
				}
			})
		} else {
			res.send({
				msg: "输入信息不能为空",
				code: -1
			})
		}
	}
	login(req, res, next) {
		let login = req.body;
		console.log(login)
		if (login.username && login.password) {
			sql.query(sqlConfig.userSearch, [login.username], result => {
				if (result.length) {
					login.password = md5(`${login.password}${PWD_SALT}`)
					if (result[0].password === login.password) {
						// let token=jswtoken.sign({payload},PRIVATE_KEY,{expiresIn:TIME_OUT} )
						let token = jswtoken.sign(login, PRIVATE_KEY, { expiresIn: TIME })
						res.send({
							msg: "登录成功~",
							token: token,
							code: 1
						})
					} else {
						res.send({
							msg: "密码错误",
							code: 2
						})
					}
				} else {
					res.send({
						msg: "用户不存在，请输入正确的用户名",
						code: 0
					})
				}
			})
		} else {
			res.send({
				msg: "用户名或密码信息不能为空",
				code: -1
			})
		}
	}
	check(req, res, next) {
		res.header("Access-Control-Allow-Origin", "*");
		let user = req.query.username
		// console.log(sqlConfig.userInfo)
		// console.log(req.query)
		if (user === "" || user === undefined) {
			res.send({
				msg: "用户名不能为空",
				code: 0
			})
		} else {
			sql.query(sqlConfig.userInfo, [user], result => {
			if (result.length) {
				res.send({
					msg: "查询成功",
					data: result,
					code: 1
				})
			} else {
				res.send({
					msg: "用户名不存在",
					code: -1
				})
			}
		})
		}
		
	}
	change(req, res, next) {
		let change = req.body
		if (change.username && change.password && change.confirm) {
			sql.query(sqlConfig.userSearch, [change.username], result => {
				if (result.length) {
					let password = change.password = md5(`${change.password}${PWD_SALT}`)
					let confirm = change.password = md5(`${change.confirm}${PWD_SALT}`)
					if (password === confirm) {
						sql.query(sqlConfig.userChange, [change.password,change.username], result =>{
                            res.send({
								name: "密码修改成功",
								code: 1,
							})
						})
						
					}
					else {
						res.send({
							name: "密码修改不成功",
							code: 1,
						})
					}

				}
				else {
					res.send({
						name: "用户名不存在，请重新输入",
						code: 2,
					})
				}
			})

		} else {
			res.send({
				name: "输入信息不能为空",
				code: -1,
			})
		}

	}
	allsearch(req, res, next) {
		res.header("Access-Control-Allow-Origin", "*");
		let allsearch = req.query
		sql.query(sqlConfig.userAll, [], result => {
			res.send({
				name: "查询成功",
				data: result,
				code: 1
			})
		})
	}
	find(req, res, next) {
		res.header("Access-Control-Allow-Origin", "*");
		sql.query(sqlConfig.userFind, [req.query.id], result => {
			res.send({
				name: "success",
				data: result,
				code: 1
			})
		})
	}
	updata(req,res,next){
		console.log(req.query)
		let updata = req.query;
		res.header("Access-Control-Allow-Origin", "*");
		sql.query(sqlConfig.userUpdata,[updata.username,updata.age,updata.phone,updata.id],result=>{
			res.send({
				msg:"更新成功",
				code:1
			})
		})
		
	}

}
module.exports = new UserCb()
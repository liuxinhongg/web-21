var express = require('express');
var router = express.Router();
let sql = require("../sql.js");
let iconv = require('iconv-lite'); //引入模块
let cbfile = require("../cbfile/cb.js")
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
 
});
// 注册
router.post('/zhuce',cbfile.zhuce)
//登录
router.post('/login',cbfile.login)
//查看
router.get('/check',cbfile.check)
//修改密码
router.post('/change',cbfile.change)
//查询全部
router.get("/allsearch",cbfile.allsearch)
//找id那一行的内容
router.get("/find",cbfile.find)
//将修改的内容给数据库
router.get("/updata",cbfile.updata)


module.exports = router;

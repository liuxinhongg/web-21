var express = require('express');
var router = express.Router();
let sql = require("../sql.js");

/* GET users listing. */
router.get('/add',(req, res, next)=> {
    let user = req.query;
    let sqladd = `insert into banner(img,name) values(?,?) `;
    let sqlall = [user.img,user.name];
    sql.query(sqladd,sqlall,result=>{
        res.send({
            msg: "插入成功",
            code: 1
        })
    })
   
})
router.get('/sort',(req, res, next)=> {
    let pool = req.query;
    let pooladd = `insert into sort(title,name,img) values(?,?,?) `;
    let poolall = [pool.title,pool.name,pool.img];
    sql.query(pooladd,poolall,result=>{
        res.send({
            msg: "插入成功",
            code: 1
        })
    })
   
})
router.get('/sortsearch', function(req, res, next) {
    let select = "insert into sortsearch(`name`,`img`,`sort`,`date`,`price`,`shop_name`,`desc`,`provcity`) values(?,?,?,?,?,?,?,?)";
    let a = req.query;
    let date = new Date()
    let year = date.getFullYear();
    let month = date.getMonth() +1;
    let ri = date.getDate();
    let hours = date.getHours();
    let miutes = date.getMinutes();
    date = `${year} 年 ${month} 月 ${ri} 日 ${hours} 小时 ${miutes} 分钟`
    console.log(typeof date)
    let data = [a.name,a.img,a.sort,date,a.price,a.shop_name,a.desc,a.provcity];

    sql.query(select, data, result => {
        res.send({
            mig: "成功",
            // data: result,
            code: 0
        })
    })
});
//详情
router.get('/yill',(req, res, next)=> {
    let pick = req.query;
    let okl= `select * from sortSearch`
    sql.query(okl,[],result=>{
        res.send({
            name: "查询成功",
            data: result,
            code: 1
        })
    })
   
})
//轮播图
router.get('/kill',(req, res, next)=> {
    let pick = req.query;
    let okl= `select * from banner`
    sql.query(okl,[],result=>{
        res.send({
            name: "查询成功",
            data: result,
            code: 1
        })
    })
   
})
//分类
router.get('/till',(req, res, next)=> {
    let pick = req.query;
    let okl= `select * from sort`
    sql.query(okl,[],result=>{
        res.send({
            name: "查询成功",
            data: result,
            code: 1
        })
    })
   
})

module.exports = router;
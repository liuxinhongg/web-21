module.exports = {
	PWD_SALT:'wanggang',
	PRIVATE_KEY:'wanggang',
	TIME:60*30
}
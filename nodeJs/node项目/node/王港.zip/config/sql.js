const sqlconfig = {
   userSearch :`select * from user where username = ?`,//通过username查询
   userInfo:`select username,age,phone from user where username=?`,
   userAll:`select * from user`,
   userInsert:`insert into user(username,password,age,phone) values(?,?,?,?)`,//新增
   userFind:`select username,age,phone from user where id =?`,
   userUpdata:`update user set username=?,age=?,phone=? where id=?`,//更新
   userChange:`update user set password=? where username = ?`
}
module.exports = sqlconfig
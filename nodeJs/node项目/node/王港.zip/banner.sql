INSERT INTO `banner` VALUES (1, 'lbt1', 'https://img12.360buyimg.com/pop/s1180x940_jfs/t1/152774/9/10716/99075/5fdffdb7E5b5a783a/ced299b5e5e468ac.jpg.webp');
INSERT INTO `banner` VALUES (2, 'lbt2', 'https://gw.alicdn.com/imgextra/i1/1725301/O1CN01Qu3L8J1p1uBqzRw7z_!!1725301-0-lubanu.jpg');
INSERT INTO `banner` VALUES (3, 'lbt3', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1183209086,540381247&fm=26&gp=0.jpg');
INSERT INTO `banner` VALUES (4, 'lbt4', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=223722862,3449104823&fm=15&gp=0.jpg');
INSERT INTO `banner` VALUES (5, 'lbt5', 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3103823167,998157689&fm=26&gp=0.jpg');
INSERT INTO `banner` VALUES (6, 'lbt6', 'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1731368861,1535363249&fm=26&gp=0.jpg');

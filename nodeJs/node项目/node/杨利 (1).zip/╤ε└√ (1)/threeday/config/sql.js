const sqlconfig = {
    userSearch:`select * from web21 where username = ? `,// 通过名字查询
    userInfo:`select username,email,phone,nick from web21 where username=?`,
	userInsert:`insert into web21(username,password,email,phone,nick) values(?,?,?,?,?)`,//新增
	// userUpdata:`update web21 set username=?,email=?,phone=?,nick=? where id=?`//更新
}
module.exports = sqlconfig;
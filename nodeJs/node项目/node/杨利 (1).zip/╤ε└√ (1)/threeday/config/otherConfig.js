module.exports = {
	PWD_SALT:'web_web21',
	PRIVATE_KEY:'zhouyuzhe',
	TIME:60*60*24
}
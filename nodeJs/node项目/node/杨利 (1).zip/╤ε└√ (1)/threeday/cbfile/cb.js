let sqlConfig = require("../config/sql.js");
let sql = require("./sql.js");
let {md5} = require("../config/method.js");
let jswtoken = require("jsonwebtoken");
let { PWD_SALT,PRIVATE_KEY,TIME } = require("../config/otherConfig.js");
const sqlconfig = require("../config/sql.js");
class Users{
  // 注册
    zhuce(req,res,next){
      let user = req.body;
      console.log(user);
      if(user.username && user.password && user.email && user.phone && user.nick){
        let sqlsearch = `select * from web21 where username = ? `;
        sql.query(sqlsearch,[user.username],result=>{
          if(result.length){
            res.send({
              msg:"用户名已存在",
              code:0
            })
          }
        })
        // let sqladd = 'insert into web21(username,password,email,phone,nick) values(?,?,?,?,?)';
        user.password = md5(`${user.password}${PWD_SALT}`);
        let sqlparams = [user.username,user.password,user.email,user.phone,user.nick];
        sql.query(sqlconfig.userInsert,sqlparams,function(result){
          res.send({
            msg:"注册成功",
            code:1
          })
        })
      }else{
        res.send({
          msg:"输入信息不能为空",
          code:-1
        })
      }
    }
  // 登录
    login(req,res,next){
      let login = req.body;
      console.log(login)
      if(login.username && login.password){
        sql.query(`select * from web21 where username = ? `,[login.username],result=>{
          if(result.length){
            login.password = md5(`${login.password}${PWD_SALT}`)
            if(result[0].password ===login.password ){
              // let token=jswtoken.sign({payload},PRIVATE_KEY,{expiresIn:TIME_OUT} )
              let token = jswtoken.sign(login,PRIVATE_KEY,{expiresIn:TIME})
              res.send({
                msg:"登录成功~",
                token:token,
                code:1
              })
            }else{
              res.send({
                msg:"密码错误",
                code:2
              })
            }
          }else{
            res.send({
              msg:"用户不存在，请输入正确的用户名",
              code:0
            })
          }
        })
      }else{
        res.send({
          msg:"用户名或密码信息不能为空",
          code:-1
        }) 
      }
    } 
  //查询用户信息
  userinfo(req,res,next){
    let login = req.body;
    if(login.username && login.password){ //登录信息不能为空
      sql.query("select * from web21 where username = ?",[login.username],result=>{
        if(result.length){
          login.password = md5(`${login.password}${PWD_SALT}`);
          console.log(login);
          if(result[0].password === login.password){
            let addsql = "select username,email,phone,nick from web21 where username=?";
            let addvalue =  [login.username];
            sql.query(addsql,addvalue,result=>{ //获取用户信息
                res.send(result);
            })
          }else{
            res.send({
              msg:"密码错误",
              code:2
            })
          }
        }else{
            res.send({
              msg:"用户不存在，请输入正确的用户名",
              code:0
            })
          }
      })
    }else{
      res.send({
        msg:"用户名或密码不能为空",
        code:-1
      })
    }
  }
  // 查询所有用户信息
  userall(req,res,next){
    res.header("Access-Control-Allow-Origin", "*");
    sql.query("select * from web21",[],result=>{
      console.log(result)
      res.send({
        data:result,
        code:1
      })
    })
  }
 // 修改 
 userxiugai(req,res,next){
    res.header("Access-Control-Allow-Origin","*");
    sql.query("select username,email,phone,nick from web21 where id=?",[req.query.id],result=>{
      res.send({
        msg:"查询成功",
        code:1,
        data:result
      })
    })
  }
  //更新
  userupdata(req,res,next){
      res.header("Access-Control-Allow-Origin","*");
      let updata = req.query;
      sql.query("update web21 set username=?,email=?,phone=?,nick=? where id=?",
      [updata.username,updata.email,updata.phone,updata.nick,updata.id],result=>{
        res.send({
          msg:"更新成功",
          code:1
        })
      })
  }
}
module.exports = new Users();
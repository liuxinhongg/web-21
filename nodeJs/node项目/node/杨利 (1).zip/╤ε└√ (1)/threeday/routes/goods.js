var express = require('express');
var router = express.Router();
var sql = require("./ys.js");
router.get('/goods', function(req, res, next) {
    let date = req.query;
    let sqladd = "insert into banner(name,img) values(?,?)";
    let sqlpram = [date.name,date.img];
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
});
router.get('/banner', function(req, res, next) {
    
    let sqladd = "select * from banner";
    let sqlpram = [];
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1,
            data:result
        })
    })
});

router.get('/good', function(req, res, next) {
    let date = req.query;
    let sqladd = "insert into sort(name,title,img) values(?,?,?)";
    let sqlpram = [date.name,date.title,date.img];
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
});
router.get('/sort', function(req, res, next) {
   
    let sqladd = "select * from sort";
    let sqlpram = [];
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1,
            data:result
        })
    })
});
router.get('/goodss', function(req, res, next) {
    let data = req.query;
    let sqladd = "insert into sortSearch(name,img,sort,date,price,status,num,shop_name,provcity,size,state) values(?,?,?,?,?,?,?,?,?,?,?)";
    // let date = new Date();
    // let Year = data.getFullYear();
    // let Month = data.getMonth()+1;
    // let day = date.getDate();
    // let hours = date.getHours();
    // let Minutes = date.getMinutes();
    // let second = date.getSeconds();
    // date = `${Year}年${Month}月${day}天${hours}小时${Minutes}分钟${second}`
    let sqlpram = [data.name,data.img,data.sort,data.date,data.price,data.status,data.num,data.shop_name,data.provcity,data.size,data.state];
    // console.log(typeof date)
    console.log(data);
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
});

module.exports = router;
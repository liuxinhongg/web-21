var express = require('express');
var router = express.Router();
// var sql = require("./ys.js");
let cbfile = require("../cbfile/cb.js");

let iconv = require('iconv-lite'); //引入模块
router.get('/', function(req, res, next) {
  res.send({
    name:"yangli",
    othername:"345"
  })
});
// 注册
router.post('/zhuce',cbfile.zhuce);
// 登录
router.post("/login",cbfile.login);
// 查看
router.post("/chakan",cbfile.userinfo);
// //查看所有用户信息
router.get("/allsearch",cbfile.userall);
// // // 修改
router.get("/findid",cbfile.userxiugai);
// // 更新
router.get("/updata",cbfile.userupdata);
module.exports = router;




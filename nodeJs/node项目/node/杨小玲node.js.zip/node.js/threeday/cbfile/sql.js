let mysql = require("mysql");
let pool = mysql.createPool({
    host:"localhost",
    user:"root",
    password:"root",
    port:"3306",
    database:"my-zone"
})
exports.query = function(sql,arr,callback){  //导出
    pool.getConnection(function(err,connection){  //试图建立到给定数据库URL的连接
        if(err){
            throw new Error();
            return;
        }
        connection.query(sql,arr,function(error,result){
            connection.release();//退出信号量并返回前一个计数
            if(error) throw error;
            callback && callback(result)
        })
    })
}
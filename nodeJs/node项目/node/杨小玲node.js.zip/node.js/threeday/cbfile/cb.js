let sql = require("./sql.js");
let sqlConfig = require("../config/sql.js")
let {md5} = require("../config/method.js");
let jswtoken = require("jsonwebtoken");
let { PWD_SALT,PRIVATE_KEY,TIME } = require("../config/otherConfig.js");
const { userId } = require("../config/sql.js");
class UserCb{
   zhuce(req,res,next){

        let user = req.body;
        if(user.username && user.password && user.phone && user.email){ //如果存在执行
          //查找数据库中是否有相同用户名
        console.log(user);
          sql.query(sqlConfig.userSearch,[user.username],result=>{
            if(result.length){
              res.send({
                msg:"用户名已存在",
                code:0
              })
            }else{
              //添加
              
              user.password = md5(`${user.password}${PWD_SALT}`)
              let sqldata = [user.username,user.password,user.phone,user.email];
               // 加入字符编码
              //var md5 = crypto.createHash('md5').update(data, 'utf-8').digest('hex');
              sql.query(sqlConfig.userInsert,sqldata,function(result){
                res.send({
                  msg:"注册成功",
                  code:1
                })
              })
            }
          })
        }else{
          res.send({
            msg:"输入信息不能为空",
            code:-1
          })
        }
    }
    login(req,res,next){
        let login = req.body;
        console.log(login);
        if(login.username && login.password){ //如果用户名和密码都存在
          sql.query(sqlConfig.userSearch,[login.username],result=>{
            if(result.length){
              console.log(result);
              login.password = md5(`${login.password}${PWD_SALT}`);
              if(result[0].password === login.password){
                let token = jswtoken.sign(login,PRIVATE_KEY,{expiresIn:TIME});
                res.send({
                  msg:"登录成功",
                  token:token,
                  code:1
                })
              }else{
                res.send({
                  msg:"密码错误",
                  code:2
                })
              }
            }else{
              res.send({
                msg:"用户名不存在",
                code:0
              })
            }
          })
        }else{
          res.send({
            msg:"用户名或密码不能为空",
            code:-1
          })
        }
      }
      // 查询用户信息
    chaxun(req,res,next){
        console.log(req.query);
        let user = req.query.username; //get请求内容在query里面
        if(user === "" && user === undefined){
          res.send({
            msg:"用户名不能为空",
            code:-1
          })
        }
        sql.query(sqlConfig.userInfo,[user],result=>{
          if(result.length){
            res.send({
              msg:"查询成功",
              data:result,
              code:1
            })
          }else{
            res.send({
              msg:"用户不存在",
              code:0
            })
          }
        })
      }
      // 查询所有用户信息
      chaxunAll(req,res,next){
        sql.query(sqlConfig.userAll,[req.query.id],result=>{
          res.send({
            msg:"查询成功",
            data:result,
            code:1
          })
        })
      }
      // 通过id查询用户信息
      findid(req,res,next){
        //通过id从数据库(user)中拿到指定的数据
        sql.query(sqlConfig.userId,[req.query.id],result=>{
          res.send({
                  msg:"success",
                  code:1,
                  data:result
              })
        })
      }
      //修改用户信息
      userUpdata(req,res,next){
		let updata = req.query;
		sql.query(sqlConfig.userUpdata,[updata.username,updata.email,updata.phone,updata.id],result=>{
			res.send({
				msg:"更新成功",
				code:1
			})
		})
		
	}
}
module.exports = new UserCb();

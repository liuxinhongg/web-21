var express = require('express');
var router = express.Router();
let sql = require("./sql.js");
let cbfile = require("../cbfile/cb.js")
//加密
// const crypto = require('crypto');
// let PWD_SALT = "web_my-zone";

// // 生成token
// jswtoken = require("jsonwebtoken");
// PRIVATE_KEY = "miyao";
// TIME = 60*60*48;
// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });


// router.get('/',function(req,res,next){
//   res.send({
//     name:"zhangsan",
//     othername:"lisi"
//   })
// })

// 注册
router.post('/zhuce',cbfile.zhuce);
// 登录
router.post("/login",cbfile.login);

// 查询用户信息
router.get("/chaxun",cbfile.chaxun);
 
// 查询所有用户信息
router.get("/chaxunAll",cbfile.chaxunAll);
// 通过id查询用户信息
router.get("/findid",cbfile.findid);

//修改用户信息
router.get("/updata",cbfile.userUpdata);
  
module.exports = router;     //导出路由
// get请求和post请求的区别有：        
// 1、GET通常把参数包含在URL中，而POST一般通过request body来传递参数。且GET产生的URL地址可以被标记，而POST不可以。
// 2、GET在浏览器回退时是无害的，而POST会再次提交请求。　　　　
// 3、GET请求参数会被完整保留在浏览器历史记录里，而POST中的参数不会被保留。(get请求参数可以在浏览器请求中看见)
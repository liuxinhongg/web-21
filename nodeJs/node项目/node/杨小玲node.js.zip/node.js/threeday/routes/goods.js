var express = require('express');
var router = express.Router();
let sql = require("./sql.js");
// /* GET home page. */
// 轮播图添加
router.get('/banner', function (req, res, next) {
    let user = req.query;
    let addsql ="insert into banner(name,img) values(?,?)";
    let sqldata = [user.name,user.img];
    sql.query(addsql,sqldata,result=>{
        res.send({
            msg: "添加成功",
            code: 1
        });
    })
   
});
// sort表添加
router.get('/sort', function (req, res, next) {
    let user = req.query;
    let addsql ="insert into sort(titile,name,img) values(?,?,?)";
    let sqldata = [user.titile,user.name,user.img];
    sql.query(addsql,sqldata,result=>{
        res.send({
            msg: "添加成功",
            code: 1
        });
    })
   
});
// sortsearch表添加
router.get('/sortSearch', function (req, res, next) {
    let user = req.query;
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var data = date.getDate();
    let time = `${year}${month}${data}`;
    console.log(user);
    let addsql ="insert into sortSearch(`name`,`img`,`sort`,`date`,`price`,`shop_name`,`size`) values(?,?,?,?,?,?,?)";
    let sqldata = [user.name,user.img,user.sort,time,user.price,user.shop_name,user.size];
    sql.query(addsql,sqldata,result=>{
        res.send({
            msg: "添加成功",
            code: 1
        });
    })
   
});
// 查询
router.get('/about', function (req, res, next) {
    let user = req.query;
    let name = user.name;
    sql.query(`select * from sortsearch where name like '%${name}%'`,[],result=>{
        res.send({
            msg: "查询成功",
            code: 1,
            data:result
        });
    })
   
});

router.get('/fenlei', function (req, res, next) {
    let user = req.query;
    console.log(user)
    sql.query(`select * from sort`,[],result=>{
        res.send({
            msg: "查询成功",
            code: 1,
            data:result
        })
    })
   
});
router.get('/bout', function (req, res, next) {
    let user = req.query;
    console.log(user)
    sql.query(`select * from banner`,[],result=>{
        res.send({
            msg: "查询成功",
            code: 1,
            data:result
        })
    })
   
});
module.exports = router;     //导出路由
// get请求和post请求的区别有：
// 1、GET通常把参数包含在URL中，而POST一般通过request body来传递参数。且GET产生的URL地址可以被标记，而POST不可以。
// 2、GET在浏览器回退时是无害的，而POST会再次提交请求。　　　　
// 3、GET请求参数会被完整保留在浏览器历史记录里，而POST中的参数不会被保留。(get请求参数可以在浏览器请求中看见)
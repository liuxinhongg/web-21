module.exports = {
	PWD_SALT:"web_my-zone",
	PRIVATE_KEY : "miyao",
    TIME: 60*60*48
}
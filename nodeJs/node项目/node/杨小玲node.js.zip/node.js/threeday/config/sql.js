const sqlconfig = {
	userSearch :`select * from user where username = ?`,//通过username查询
	userInfo:`select username,email,phone from user where username=?`,//通过username查询
    userInsert:`insert into user(username,password,phone,email) values(?,?,?,?)`,//新增
    userAll:`select * from user`,//查询所有
    userId:`select username,email,phone from user where id =?`,//通过id查询,
    userUpdata:`update user set username=?,email=?,phone=? where id=?`//更新
}
module.exports = sqlconfig
var express = require('express');
var router = express.Router();
var sql = require("../sql");
router.get('/goods', function (req, res, next) {
    let date = req.query;
    console.log(date);
    let sqladd = `insert into banner(title,img) values(?,?)`;
    let sqlpram = [date.title, date.img];
    sql.query(sqladd, sqlpram, result => {
        res.send({
            msg: "添加成功",
            code: 1
        })
    })
});
router.get('/good', function(req, res, next) {
    let date = req.query;
    let sqladd = `insert into sort(name,title,img) values(?,?,?)`;
    let sqlpram = [date.name,date.title,date.img];
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
});
router.get('/goodss', function(req, res, next) {
    let data = req.query;
    let sqladd = `insert into sortsearch(name,sort,date,price,status,num,shop_name,provcity,state,size,img) values(?,?,?,?,?,?,?,?,?,?,?)`;
    let sqlpram = [data.name,data.sort,data.date,data.price,data.status,data.num,data.shop_name,data.provcity,data.state,data.size,data.img];
    console.log(data);
    sql.query(sqladd,sqlpram,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
});

module.exports = router;
let sql = require("./02.js");//引入sql模块
let sqlconfig = require("../config/sql.js");
let { md5 } = require("../config/fangfa.js");
let { PWD_SALT, PRIVATE_KEY, TIME_OUT } = require("../config/other.js");
let jswtoken = require("jsonwebtoken");
// const crypto = require('crypto');//引入crypto模块
// function md5(s) {
//     return crypto.createHash("md5").update(String(s)).digest("hex");
//   }
class User {
    zhuce(req, res, next) {
        let user = req.body;
        // console.log(req);
        if (user.username && user.password && user.email && user.phone) {
            // let list1 = "select * from user where username = ?";
            sql.query(sqlconfig.userselect, [user.username], result => {
                if (result.length) {
                    res.send({
                        msg: "用户名已存在",
                        code: 0
                    })
                } else {
                    user.password = md5(`${user.password}${PWD_SALT}`);//加密
                    let addlist = [user.username, user.password, user.email, user.phone];
                    sql.query(sqlconfig.userinsert, addlist, result => {
                        res.send({
                            msg: "注册成功",
                            code: 1
                        })
                    })
                }
            })
        } else {
            res.send({
                msg: "输入信息不能为空",
                code: -1
            })
        }
    };
    denglu(req, res, next) {
        let denglu = req.body;
        if (denglu.username && denglu.password) {
            sql.query(sqlconfig.userselect, [denglu.username], result => {
                if (result.length) {
                    denglu.password = md5(`${denglu.password}${PWD_SALT}`);//加密
                    if (result[0].password === denglu.password) {
                        let token = jswtoken.sign(denglu,PRIVATE_KEY,{expiresIn:TIME_OUT})//添加token
                        res.send({
                            msg: "登录成功~",
                            token: token,
                            code: 1
                        })
                    } else {
                        res.send({
                            msg: "密码错误",
                            code: 2
                        })
                    }
                } else {
                    res.send({
                        msg: "用户不存在，请输入正确的用户名",
                        code: 0
                    })
                }
            })
        } else {
            res.send({
                msg: "用户名或密码信息不能为空",
                code: -1
            })
        }
    };
    chaxun(req, res, next) {
        let chaxun = req.body;//获取前端发的数据
        if (chaxun === "" || chaxun === undefined) {
            res.send({
                msg: "用户名不能为空",
                code: 0
            })
        }
        console.log(chaxun);
        sql.query(sqlconfig.usersearch, [chaxun.username], result => {
            if (result.length) {
                res.send({
                    msg: "查询成功",
                    data: result,
                    code: 1
                })
            } else {
                console.log(result);
                res.send({
                    msg: "用户名不存在",
                    code: -1
                })
            }
        })
    };
    quanbu(req, res, next) {
        sql.query(sqlconfig.userall, [], result => {
            console.log(result);
            res.send({
                data: result,
                code: 1
            })
        })
    };

    find(req, res, next) {
        let find = req.body;
        sql.query(sqlconfig.userfind, [find.id], result => {//find.id 通过id查找
            console.log(result);
            res.send({
                msg: "成功",
                code: 1,
                data: result //把找到的内容返回出去
            })
        })
    }
    xiugai(req, res, next) {
        let xiugai = req.body;

        let list1 = [sqlconfig.userupdate.username, xiugai.email, xiugai.phone, xiugai.id];
        sql.query(list, list1, result => {
            res.send({
                msg: "修改成功",
                code: 1
            })
        })
    }
}
module.exports = new User();
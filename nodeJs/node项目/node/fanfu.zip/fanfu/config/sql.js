const sqlconfig = {
    userselect:"select * from user where username = ?",//通过username查询
    userinsert:"insert into user(username,password,email,phone) values(?,?,?,?)",//新增
    usersearch:"select username,email,phone from user where username = ?",
    userupdate:"update user set username = ?,phone = ?,email = ? where id = ?",
    userall:"select * from user",
    userfind:"select username,email,phone from user where id = ?"
}
module.exports = sqlconfig;
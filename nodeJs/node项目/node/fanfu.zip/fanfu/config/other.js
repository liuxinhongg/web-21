module.exports = {
    PWD_SALT:"web_web21",
    PRIVATE_KEY:"yangxiaoling",
    TIME_OUT:60*60
}
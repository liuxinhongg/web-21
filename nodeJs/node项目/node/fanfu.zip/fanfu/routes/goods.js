let express = require('express');
let router = express.Router();
let sql = require("../02.js");
//轮播图
router.get("/insert",(req,res,next)=>{
    let banner = req.query;
    let list = "insert into banner(img,name) values(?,?)";//插入语句
    let addlist = [banner.img,banner.name];
    sql.query(list,addlist,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
    
});
//分类
router.get("/fenlei",(req,res,next)=>{
    let banner = req.query;
    let list = "insert into sort(img,name,title) values(?,?,?)";//插入语句
    let addlist = [banner.img,banner.name,banner.title];
    sql.query(list,addlist,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
    
})
//分类查询
router.get("/chaxun",(req,res,next)=>{
    let banner = req.query;
    let date = new Date();
    let year = date.getFullYear();
    let month = date.getMonth()+1;
    let data = date.getDate();
    let time = `${year}:${month}:${data}`;
    console.log(banner);
    let list = "insert into sortsearch(`name`,`img`,`sort`,`date`,`price`,`shop_name`,`size`) values(?,?,?,?,?,?,?)";//插入语句
    let addlist = [banner.name,banner.img,banner.sort,time,banner.price,banner.shop_name,banner.size];
    sql.query(list,addlist,result=>{
        res.send({
            msg:"添加成功",
            code:1
        })
    })
    
})
//查询
router.get("/login1",(req,res,next)=>{
    let login = req.query;
    console.log(login);
    let list = "select * from banner";//查询语句
    sql.query(list,[],result=>{
        res.send({
            msg:"查询成功",
            code:1,
            data:result
        })
    }) 
})
router.get("/login",(req,res,next)=>{
    let login = req.query;
    console.log(login);
    let list = "select * from sort";//查询语句
    sql.query(list,[],result=>{
        res.send({
            msg:"查询成功",
            code:1,
            data:result
        })
    })
    
})
//模糊查询
router.get("/sort",(req,res,next)=>{
    let login = req.query;
    console.log(login);
    let list = "select * from sortsearch where sort like '%家纺%'";
    sql.query(list,[],result=>{
        res.send({
            msg:"查询成功",
            code:1,
            data:result
        })
    })
})
router.get("/sort1",(req,res,next)=>{
    let login = req.query;
    console.log(login);
    let list = "select * from sortsearch where name like '%羽绒服%'";
    sql.query(list,[],result=>{
        res.send({
            msg:"查询成功",
            code:1,
            data:result
        })
    })
})
router.get("/sort2",(req,res,next)=>{
    let login = req.query;
    console.log(login);
    let name = login.name;
    let list = `select * from sortsearch where name like '%${name}%'`;
    res.setHeader("content-type","text/html;charset=utf-8");
    sql.query(list,[],result=>{
        res.send({
            msg:"查询成功",
            code:1,
            data:result
        })
    })
    
})
module.exports = router;
    

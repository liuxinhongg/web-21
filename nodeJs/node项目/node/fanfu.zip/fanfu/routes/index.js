let express = require('express');
let router = express.Router();
let sql = require("../02.js");
let iconv = require("iconv-lite");
let cbfile = require("../cbfile/sql.js");//引入模块
//加密
// let PWD_SALT = "web_web21";
// const crypto = require('crypto');//引入crypto模块
// function md5(s) {
//   return crypto.createHash("md5").update(String(s)).digest("hex");
// }
//生成token
// let jswtoken = require("jsonwebtoken");//添加jsonwebtoken模块
// let PRIVATE_KEY = "yangxiaoling";//密钥
// let TIME_OUT = 60*60;//过期时间
/* GET home page. */
router.get('/', function (req, res, next) {//渲染
  res.render('index', { title: 'Express' });
  // res.send({
  //   name: "yangxiaoling",
  //   othername: "gua"
  // })
});
//注册
router.post("/zhuce",cbfile.zhuce);
//登录
router.post("/denglu",cbfile.denglu); 
//查询用户信息
router.post("/chaxun",cbfile.chaxun);
//查询全部
router.post("/quanbu",cbfile.quanbu);
//查询用户id
router.post("/find",cbfile.find);
//修改用户信息
router.post("/xiugai",cbfile.xiugai)
module.exports = router;

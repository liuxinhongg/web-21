var express = require('express');
var router = express.Router();
let sql = require("../pool");
let file = require("../cbfile/file");

//加密
// var crypto = require('crypto');
// let PWD_SALT = "JIANH";
// function md5(s) {
//   //注意参数必须是string类型,不然会报错
//   return crypto.createHash("md5").update(String(s)).digest('hex')
// }


//生成token
// let jsontoken = require("jsonwebtoken");
// const { zhuce } = require('../cbfile/file');
// let KEY = "jie";     //设置密钥
// let TIME = 20 * 60;

/* GET home page. */
router.get('/1.html', function (req, res, next) {
  // res.render('index', { title: 'Express' });
  res.send({
    msg: "jie",
    age: 2
  })
});

router.post('/zhuce',file.zhuce);


router.post('/denglu',file.denglu);

//查看用户名
router.post('/chakan',file.chakan);
//查看所有
router.post('/onchakan',file.onchakan);
//修改
router.post('/xiugai', file.xiugai);
//更新
router.post('/gengxin',file.gengxin);

module.exports = router;

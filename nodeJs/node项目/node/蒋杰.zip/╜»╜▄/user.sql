INSERT INTO `user` VALUES (4, 'jie', '111', '2');
INSERT INTO `user` VALUES (6, 'jie', '111', '2');
INSERT INTO `user` VALUES (8, 'ggggkkkkkkkkkk', 'adsasd', 'asdasdjjjjjjjj');
INSERT INTO `user` VALUES (10, 'SD', 'sad', 'sad');
INSERT INTO `user` VALUES (48, 'fanfu', '86e1066fc540b0daddb4cfb9a89a6e2e', 'fanfu');
INSERT INTO `user` VALUES (49, 'hh', 'cec81c146844e88a1f603db5a65c6bce', 'gg');
INSERT INTO `user` VALUES (50, 'kkkkk', '86e1066fc540b0daddb4cfb9a89a6e2e', '111');

module.exports = {
    PWD_SALT : "JIANH",  //名字
    KEY : "jie",   //密钥
    TIME : 20 * 60,  //过期时间
}
const selectCRUD = {
   selectuser :`select * from user where user = ?`,  //通过user查看
   selectjia :  `insert into user(user,password,age) values(?,?,?)`, //添加
   selectaut:`select * from user`,
   select:`select user,age from user where id =?`,
   updata :`UPDATE user SET user = ?,age = ? WHERE id = ?`
}



module.exports = selectCRUD
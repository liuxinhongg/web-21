let mysql = require("mysql");
let pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    port: '3306',
    database: 'first'
})
exports.query = function (sql, arr, callback) {
    pool.getConnection((err, connection) => {
        if (err)  throw  new Error();
        connection.query(sql, arr, (err, result) => {
            connection.release();         //释放接口 外界打开
            if (err) throw new Error();
            callback && callback(result)
        })
    })
}
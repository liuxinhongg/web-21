let sql = require("../pool");
let selectCRUD = require("../config/selectCRUD");
let { md5 } = require('../config/md5');
let { PWD_SALT, KEY, TIME } = require('../config/keytime');

//生成token
let jsontoken = require("jsonwebtoken");


class Flie {
    zhuce(req, res, next) {
        console.log(res)
        // let user = req.body.user;
        // let password = req.body.password;
        // let age = req.body.age;
        let aa = req.body;
        if (aa.user && aa.password && aa.age) {
            sql.query(selectCRUD.selectuser, [aa.user], result => {
                console.log(1)
                if (result.length) {
                    res.send({
                        msg: "用户名已存在",
                        code: 0
                    })
                } else {
                    var b = [aa.user, md5(`${aa.password}${PWD_SALT}`), aa.age];
                    sql.query(selectCRUD.selectjia, b, (result) => {
                        res.send({
                            msg: "注册成功",
                            code: 1
                        })
                    })
                }
            })
        } else {
            res.send({
                msg: "输入信息不能为空",
                code: -1
            })
        }
    }

    denglu(req, res, next) {
        let denglu = req.body;
        console.log(denglu);
        if (denglu.user && denglu.password) {

            sql.query(selectCRUD.selectuser, [denglu.user], (result) => {
                if (result.length) {
                    denglu.password = md5(`${denglu.password}${PWD_SALT}`);
                    if (result[0].password === denglu.password) {
                        let token = jsontoken.sign({ denglu }, KEY, { expiresIn: TIME });
                        res.send({
                            msg: "登录成功",
                            token: token,
                            code: 1
                        })
                    } else {
                        res.send({
                            msg: "密码错误",
                            code: 0
                        })
                    }
                } else {
                    res.send({
                        msg: "用户不存在，请输入正确的用户名",
                        code: -2
                    })
                }
            })
        } else {
            res.send({
                msg: "用户名或信息不能为空",
                code: -1
            })
        }
    }

    chakan(req, res, next) {
        let chakan = req.body;
        if (chakan.user) {
            sql.query(selectCRUD.selectuser, [chakan.user], (result) => {
                if (result.length) {
                    res.send({
                        msg: "查看成功",
                        result
                    })
                } else {
                    res.send({
                        msg: "用户名不存在,请输正确用户名",
                        code: -1
                    })
                }
            })
        } else {
            res.send({
                msg: "用户名不能为空",
                code: 0
            })
        }
    }
    onchakan(req, res, next) {
        sql.query(selectCRUD.selectaut, [], (result) => {
            console.log(result)
            res.send({
              data: result,
              code: -1
            })
          })
    }
    xiugai(req, res, next) {
        sql.query(selectCRUD.select, [req.body.id], result => {
            res.send({
                mig: "修改成功",
                data: result,
                code: -1
            })
        })
    }
    gengxin(req, res, next) {
        sql.query(selectCRUD.updata, [req.body.user, req.body.age,req.body.id], result => {
          console.log(result)
          res.send({
            mig: "更新成功",
            code: 5
          })
        })
      }
}
module.exports = new Flie()
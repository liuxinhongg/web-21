INSERT INTO `banner` VALUES (1, 'https://b.appsimg.com/upload/momin/2020/12/23/41/1608720208525.jpg', '轮播图');
INSERT INTO `banner` VALUES (2, 'https://img12.360buyimg.com/pop/s1180x940_jfs/t1/152774/9/10716/99075/5fdffdb7E5b5a783a/ced299b5e5e468ac.jpg.webp', '轮播图');
INSERT INTO `banner` VALUES (3, 'https://aecpm.alicdn.com/imgextra/i4/4184230178/O1CN01YcPEgf1DBZ93uzqfk_!!4184230178-0-alimamazszw.jpg', '轮播图');
INSERT INTO `banner` VALUES (4, 'https://gw.alicdn.com/imgextra/i1/1725301/O1CN01Qu3L8J1p1uBqzRw7z_!!1725301-0-lubanu.jpg', '轮播图');
INSERT INTO `banner` VALUES (5, 'https://img14.360buyimg.com/pop/s1180x940_jfs/t1/141257/27/19714/74746/5fe18bd8E62986d4b/c1225a771d5091c0.jpg.webp', '轮播图');
INSERT INTO `banner` VALUES (6, 'https://img14.360buyimg.com/da/s1180x940_jfs/t1/150379/34/3456/84040/5f86fd2eE9352f72f/9b53ff823e092810.jpg.webp', '轮播图');

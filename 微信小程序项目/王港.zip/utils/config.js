const apiConfig = 'http://localhost:3000';
// JS
const ajax= {
  get(url,data,success){
    wx.request({
      url: apiConfig+url,
      data,
      method:'GET',
      success,
    })
  },
  promiseGet(url,data,success){
    return new Promise((resolve,reject)=>{
      wx.request({
        url: apiConfig+url,
        data,
        success:resolve,
        fail:reject
      })
    })
  }
}
export default ajax
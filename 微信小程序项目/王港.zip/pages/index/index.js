//index.js
//获取应用实例
const app = getApp()
import $ from "../../utils/config"

Page({
  data: {
    background:[],
    sort:[],
    aaa:[]
  },
  abc(){
    wx.navigateTo({
      url:"../search/search"
    })
  },
  //事件处理函数
  jump(e){
    //  console.log(e)
     wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'info',
    })
    wx.switchTab({
      url: '../classify/classify',
    })
  },
  jumpp(e){
    // console.log(e)
    wx.setStorage({
      data: e.currentTarget.dataset.id,
      key: 'info',
    })
    wx.navigateTo({
      url: '../logs/logs?info=' + e.currentTarget.dataset.id,
    })
  },
  
  onLoad: function () {
    $.get('/goods/all',{},res=>{
      // console.log(res)
      this.setData({
        background:res.data.data
      })
    }),
    $.get('/goods/bill',{},res=>{
      // console.log(res)
      this.setData({
        sort:res.data.data
      })
    }),
    $.get('/goods/cill',{},res=>{
      // console.log(res)
      this.setData({
        aaa:res.data.data
      })
    })
  }
})

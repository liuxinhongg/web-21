//logs.js
import $ from "../../utils/config"

Page({
  data: {
    add:[]
  },
  jump(e){
     wx.switchTab({
       url: '../shop/shop',
     })
  },
  shop(){
    // console.log(this.data.add)
    const list = this.data.add 
    wx.getStorage({
      key: 'search',
      success:res=>{
        // console.log(res)
        res.data.push(list[0])
        wx.setStorage({
          data: res.data,
          key: 'search',
          success:()=>{
            wx.showLoading({
              title: '成功加入购物车',
            })
            setTimeout(function(){
              wx.hideLoading()
              wx.switchTab({
                url: '../shop/shop',
              })
            },1000)
          }
        })
      },
      fail:res=>{
        const search = []
        search.push(list[0])
        wx.setStorage({
          data: search,
          key: 'search',
          success:()=>{
            wx.showLoading({
              title: '成功加入购物车',
            })
            setTimeout(function(){
              wx.hideLoading()
              wx.switchTab({
                url: '../shop/shop',
              })
            },1000)
          }
        })
      }
    })
  },
  onLoad: function () {
    wx.getStorage({
      key: 'info',
      success:res=>{
        console.log(res)
        wx.request({
          url: `http://localhost:3000/goods/fill?id=${res.data}`,
          success:res=>{
            console.log(res)
            this.setData({
              add:res.data.data
            })
          }
        })
      }
    })
  }
})

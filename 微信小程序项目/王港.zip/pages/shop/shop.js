// pages/shop/shop.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      ok:[],
      money: 0,
      selectAllStatus:false
    },
    deleteList(e) {
          let that = this
          wx.showModal({
            title: '提示',
            content: '您确定删除吗',
            success(res) {
              if (res.confirm) {
      //           console.log('用户点击确定')
                const index = e.currentTarget.dataset.index;
                // 删除购物车列表里这个商品
                wx.getStorage({
                  key: 'search',
                  success: res => {
                    let _carts = res.data;
      //               console.log(res)
                    _carts.splice(index, 1);
                    wx.setStorage({
                      data: _carts,
                      key: 'search',
                      success: res => {
                        that.setData({
                          ok: _carts
                        })
                      }
                    })
                  }
      
                })
      
              } 
            }
          })
        },
    getTotalPrice() {
      let ok = this.data.ok;                  // 获取购物车列表
      let total = 0;
      for(let i = 0; i<ok.length; i++) {         // 循环列表得到每个数据
          if(ok[i].selected) {                   // 判断选中才会计算价格
              total += ok[i].num * ok[i].price;     // 所有价格加起来
          }
      }
      this.setData({                                // 最后赋值到data中渲染到页面
          ok: ok,
          money: total.toFixed(2)
      });
  },
    selectAll(e) {
      let selectAllStatus = this.data.selectAllStatus;    // 是否全选状态
      selectAllStatus = !selectAllStatus;
      let ok = this.data.ok;
  
      for (let i = 0; i < ok.length; i++) {
          ok[i].selected = selectAllStatus; 
      }
      this.setData({
          selectAllStatus: selectAllStatus,
          ok: ok
      });
      this.getTotalPrice();              // 重新获取总价
  },
  selectList(e) {
    const index = e.currentTarget.dataset.index;    // 获取data- 传进来的index
    let ok = this.data.ok;                    // 获取购物车列表
    const selected = ok[index].selected;         // 获取当前商品的选中状态
    ok[index].selected = !selected;              // 改变状态
    this.setData({
        ok: ok
    });
    for(var i = 0;i < ok.length; i++){
      if(this.data.selectAllStatus){
        if(!ok[i].selected){
          this.setData({
            selectAllStatus: false
          });
          break;
        }
      }else{
        if(ok[i].selected){
          this.setData({
            selectAllStatus: true
          });
        }else {
          this.setData({
            selectAllStatus: false
          });
          break;
        }  
      }
    }
    this.getTotalPrice(); 
},
    jian(e){
        const index = e.currentTarget.dataset.index;
        let ok = this.data.ok;
        let num = parseInt(ok[index].num);
        if(num <= 1){
           return false;
        }
        num = num - 1;
        ok[index].num = num;
        this.setData({
           ok: ok
        });
        this.getTotalPrice(); 
        
    },
    jia(e){
        const index = e.currentTarget.dataset.index;
        let ok = this.data.ok;
        let num = parseInt(ok[index].num);
        num = num + 1;
        ok[index].num = num;
        this.setData({
          ok: ok
        });
        this.getTotalPrice(); 
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
       
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        wx.getStorage({
            key: 'search',
            success:res=>{
              //  console.log(res)
               this.setData({
                   ok:res.data,
               })
            }
          })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})
// pages/classify/classify.js
import $$ from "../../utils/config"
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        sort:[],
        sortsearch:[],
        name:""
    },
    abc(){
      wx.navigateTo({
        url:"../search/search"
      })
    },
    ddd(e){
        // console.log(e)
        wx.setStorage({
          data: e.currentTarget.dataset.id,
          key: 'info',
        })
        wx.navigateTo({
          url: '../logs/logs?info=' + e.currentTarget.dataset.id,
        })
      },

    choose(e){
        // console.log(e.currentTarget.dataset.name)
        this.setData({
            name:e.currentTarget.dataset.name
        })
        wx.setStorage({
          data: e.currentTarget.dataset.name,
          key: 'info',
          success:res=>{
              this.ajax(e.currentTarget.dataset.name)
          }
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
       
    },
    ajax(sort){
        wx.request({
          url: `http://localhost:3000/goods/dell?sort=${sort}`,

          success:res=>{
              console.log(res)
            this.setData({
                sortsearch:res.data.data
              })
          }
        })
       
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        $$.get('/goods/bill',{},res=>{
            // console.log(res)
            this.setData({
              sort:res.data.data,
              name:"女装"
            })
        })
        this.ajax("女装")
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
       wx.getStorage({
         key: 'info',
         success:res=>{
            this.ajax(res.data)
            this.setData({
                name:res.data
              })
         }
       })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})
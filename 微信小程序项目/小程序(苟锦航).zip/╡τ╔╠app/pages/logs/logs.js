const util = require('../../utils/util.js');
const app = getApp();
import $ from "../../utils/apiConfig"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    logs: [],
    bannerList:[],
    sortList:[],
    sortsearchList:[],
    kuan:850,
    name:''
  },
  // 数据
  // jumpsort(e){
  //   console.log(e.currentTarget.dataset),
  //   this.setData({
  //     name:e.currentTarget.dataset.id
  //   })
  //   wx.navigateTo({
  //     url: '../person/person',
  //   })
  // },
  jumpsortz(e){
    console.log(e.currentTarget.dataset),
    this.setData({
      name:e.currentTarget.dataset.id
    })
    wx.navigateTo({
      url: '../page/page?info='+e.currentTarget.dataset.id,
    })
  },
  jumpsousuo(e){
    wx.navigateTo({
      url: '../sousuo/sousuo',
    })
  },
  jump(e){
    this.setData({
      name:e.currentTarget.dataset.name
    })
    // 数据
    let sort = e.currentTarget.dataset.name;
    $.get('/goods/sortsearch',{sort},res=>{
      console.log(res)
      // let shuj = res.data.data
      this.setData({
        sortsearchList:res.data.data
      })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    $.get('/goods/sortsearch',{sort:"女装"},res=>{
      console.log(res)
      // let shuj = res.data.data
      this.setData({
        sortsearchList:res.data.data
      })
    })
    // 轮播图
    $.get('/goods/banner',{},res=>{
      console.log(res)
      this.setData({
        bannerList:res.data.data
      })
    })
    // 导航
    $.get('/goods/sort',{},res=>{
      // console.log(res)
      this.setData({
        sortList:res.data.data
      })
    })
    // 数据
    // $.get('/goods/sortsearchl',{},res=>{
    //   // console.log(res)
    //   this.setData({
    //     sortsearchlList:res.data.data
    //   })
    // })
    // 轮播图
    // wx.request({
    //   url: 'http://localhost:3000/goods/banner',
    //   method:'GET',
    //   success:res=>{
    //     // console.log(res);
    //     this.setData({
    //       bannerlist:res.data.data
    //     })
    //   }
    // })
    // 导航
    // wx.request({
    //   url: 'http://localhost:3000/goods/sort',
    //   method:'GET',
    //   success:res=>{
    //     // console.log(res);
    //     this.setData({
    //       sortlist:res.data.data
    //     })
    //   }
    // })
    // 数据
    // wx.request({
    //   url: 'http://localhost:3000/goods/sortsearch',
    //   method:'GET',
    //   success:res=>{
    //     // console.log(res);
    //     this.setData({
    //       sortsearchlist:res.data.data
    //     })
    //   }
    // })
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})

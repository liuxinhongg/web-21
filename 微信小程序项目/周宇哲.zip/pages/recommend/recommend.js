// pages/recommend/recommend.js
const app = getApp();
import $ from "../../utils/promise"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ulist: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.request({
      url: 'http://localhost:3000/goods/sort',
      method: "GET",
      success: res => {
        console.log(res);
        this.setData({
          ulist: res.data.data
        })
      }
    })
  },
  // sousuo
  jump(e) {
    console.log(e.currentTarget.dataset.name);
    let name = e.currentTarget.dataset.name
    $.promiseGet("/goods/sortsearch", { sort: name }).then(res => {
      console.log(res);
      this.setData({
        search: res.data.data
      })
    })
    // $.promiseGet("/goods/sortsearch",{sort:}).then(res=>{
    //   console.log(res);
    //   this.setData({
    //     search:res.data.data
    //   })
    // })
  },
  // sousuo
  goSearch(e) {
    console.log(e);
    let formData = e.detail.value;
    if (formData) {
      $.promiseGet("/goods/sortsearch", { sort: formData }).then(res => {
        console.log(res);
        this.setData({
          search: res.data.data
        })
      })
    } else {
      wx.showToast({
        title: '输入不能为空',
      })
    }

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// pages/particulars/particulars.js
import $ from "../../utils/promise"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nav: [],
    content: [],
    shop: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'info',
      success: res => {
        wx.request({
          url: `http://localhost:3000/goods/all?id=${res.data}`,
          success: res => {
            this.setData({
              nav: res.data.data
            })
          }
        })
      }
    })
    let id = options.info;
    $.get('/goods/all',{id:id},res=>{
      this.setData({
        shop:res.data.data
      })
    })
    wx.getStorage({
      key: 'if',
      success: res => {
        this.setData({
          content: res.data
        })
      }
    })
  },
  addJump() {
    wx.switchTab({
      url: '../shoppingTrolley/shoppingTrolley',
    })
  },
  add(e) {
    let data = e.currentTarget.dataset.obj[0];
    let content = this.data.content || [];
    content.push(data);
    wx.setStorage({
      data: content,
      key: 'if',
    })
    wx.showToast({
      title:"加入成功"
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
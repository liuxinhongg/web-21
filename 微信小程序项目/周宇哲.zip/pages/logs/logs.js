//logs.js
const app = getApp();
import $ from "../../utils/promise"
Page({
  data: {
    ulist: [],
    sortsearch: [],
    name: '男装'
  },
  // 查询
  inpSou() {
    wx.navigateTo({
      url: "../recommend/recommend"
    })
  },
  // 点击事件
  cli(e) {

    wx.request({
      url: 'http://localhost:3000/goods/sortsearch',
      data: {
        sort: e.currentTarget.dataset.name
      },
      method: "GET",
      success: res => {
        console.log(res);
        this.setData({
          sortsearch: res.data.data,
          name: e.currentTarget.dataset.name
        })
        wx.setStorage({
          key: 'key',
          data: e.currentTarget.dataset.name,
        })
      }
    })
  },
  jumpNav(e) {
    console.log(e.currentTarget.dataset.id);
    wx.setStorage({
      data: e.currentTarget.dataset.id,
      key: 'info',
    })
    wx.navigateTo({
      url: '../particulars/particulars?info=' + e.currentTarget.dataset.id,

    })
  },
  onShow: function () {
    wx.getStorage({
      key: 'key',
      success: res => {
        console.log(res.data);
        wx.request({
          url: 'http://localhost:3000/goods/sortsearch',
          data: {
            sort: res.data
          },
          method: "GET",
          success: res => {
            console.log(res);
            this.setData({
              sortsearch: res.data.data
            })
          }
        })
      }
    })
  },
  onReady: function (e) {
    wx.request({
      url: 'http://localhost:3000/goods/sortsearch',
      data: {
        sort: "男装"
      },
      method: "GET",
      success: res => {
        console.log(res);
        this.setData({
          sortsearch: res.data.data
        })
        wx.setStorage({
          data: "男装",
          key: 'key',
        })
      }
    })
    wx.request({
      url: 'http://localhost:3000/goods/sort',
      method: "GET",
      success: res => {
        console.log(res);
        this.setData({
          ulist: res.data.data
        })
      }
    })
  }
})
//index.js
//获取应用实例
const app = getApp()

import $ from "../../utils/promise"

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    bannerlist: [],
    ulist: [],
    sortsearch: [],
    price: [],
    seckill:[],
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  inpSou() {
    wx.navigateTo({
      url: "../recommend/recommend"
    })
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  on(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'key',
      success: res => {
        this.setData({
          name: e.currentTarget.dataset.name
        })
      }
    })
  },
  jump(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'data',
      success: (res) => {
        console.log(res);
        wx.switchTab({
          url: '../logs/logs',
        })
      }
    })
  },
  jumpNav(e){
    console.log(e.currentTarget.dataset.id);
    wx.setStorage({
      data: e.currentTarget.dataset.id,
      key: 'info'
    })
    wx.navigateTo({
      url: '../particulars/particulars?info='+e.currentTarget.dataset.id,

    })
  }, 
  jumpPage(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'info',
      success: res => {
        wx.switchTab({
          url: '../logs/logs',
          name: e.currentTarget.dataset.name
        })
      }
    })
  },
  onLoad: function (options) {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    // 轮播图
    $.promiseGet("/goods/banner", {}).then(res => {
      console.log(res);
      this.setData({
        bannerlist: res.data.data
      })
    }),
    // 内容
    $.promiseGet("/goods/sortsearch", {sort:"男装"}).then(res => {
      console.log(res.data.data);
      this.setData({
        sortsearch: res.data.data
      })
    }),
    // 列表
    $.promiseGet("/goods/sort", {}).then(res => {
      this.setData({
        ulist: res.data.data
      })
    })
    // 京东秒杀
    $.promiseGet("/goods/sort",{}).then(res=>{
      this.setData({
        price:res.data.data
      })
    })
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})

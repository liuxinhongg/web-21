const app = getApp()
import $ from "../../utils/promise"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bannerlist: [],
    ulist: [],
    sortsearch: [],
    price: [],
    seckill:[]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  on(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'key',
      success: res => {
        this.setData({
          name: e.currentTarget.dataset.name
        })
      }
    })
  },
  //详情
  jumpNav(e){
    console.log(e.currentTarget.dataset.id);
    wx.setStorage({
      data: e.currentTarget.dataset.id,
      key: 'info',
    })
    wx.navigateTo({
      url: '../particulars/particulars?info='+e.currentTarget.dataset.id,

    })
  }, 
  jumpPage(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'info',
      success: res => {
        wx.switchTab({
          url: '../logs/logs',
          name: e.currentTarget.dataset.name
        })
      }
    })

    // this.setData({
    //   ulist:e.currentTarget.dataset.name
    // })
    // // wx.setStorage({
    // //   data:e.currentTarget.dataset.name,
    // //   key:'info'
    // // })
    // wx.switchTab({
    //   url: '../logs/logs',
    // })
  },

  onLoad: function (options) {
    // wx.request({
    //   url: 'http://localhost:3000/goods/banner',
    //   method: "GET",
    //   success: res => {
    //     this.setData({
    //       bannerlist: res.data.data
    //     })
    //   }
    // })
    // 轮播图
    $.promiseGet("/goods/banner", {}).then(res => {
      console.log(res);
      this.setData({
        bannerlist: res.data.data
      })
    }),
    // 内容
    $.promiseGet("/goods/sortsearch", {sort:"男装"}).then(res => {
      console.log(res.data.data);
      this.setData({
        sortsearch: res.data.data
      })
    }),
    // wx.request({
    //   url: 'http://localhost:3000/goods/sort',
    //   method: "GET",
    //   success: res => {
    //     this.setData({
    //       ulist: res.data.data
    //     })
    //   }
    // })
    // 列表
    $.promiseGet("/goods/sort", {}).then(res => {
      this.setData({
        ulist: res.data.data
      })
    })
    // 京东秒杀
    $.promiseGet("/goods/sort",{}).then(res=>{
      this.setData({
        price:res.data.data
      })
    })
  },
  jump(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'data',
      success: (res) => {
        console.log(res);
        wx.switchTab({
          url: '../logs/logs',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    wx.getStorage({
      key: 'info',
      success: res => {
        // console.log(res.data);
        // wx.request({
        //   url: 'http://localhost:3000/goods/sortsearch',
        //   data: {
        //     sort: res.data
        //   },
        //   method: "GET",
        //   success: res => {
        //     console.log(res);
        //     this.setData({
        //       sortsearch: res.data.data
        //     })
        //   }
        // })

      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
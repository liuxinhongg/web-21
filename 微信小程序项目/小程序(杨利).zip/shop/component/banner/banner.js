// comporment/banner.js.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
      imgList:{
        type:Array,
        value:[],
        observer:{
            imgList:res=>{
            this.setData({
              background:res
            })
          }
        }
      },
      url:{
        type:String,
        value:'',
      },
      bannerHeight:{
        type:String,
        value:'',
      },
      bannerWidth:{
        type:String,
        value:'',
      },
  },
  

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})

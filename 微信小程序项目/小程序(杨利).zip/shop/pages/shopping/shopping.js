// pages/details/details.js
const util = require('../../utils/util.js')
import $ from "../../utils/apiconfig"
Page({


  /**
   * 页面的初始数据
   */
  data: {
    otherlist: [],
    carts: [], // 购物车列表
    hasList: false, // 列表是否有数据
    totalPrice: 0, // 总价，初始为0
    selectAllStatus: false // 全选状态，默认全选

  },

  addCount(e) {
    console.log(e)
    const index = e.currentTarget.dataset.index;

    let carts = this.data.carts;
    let num = +carts[index].num;
    if (num >= 10) {
      return false;
    }
    console.log(1)
    num = num + 1;
    console.log(2)
    carts[index].num = num;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
  },
  // 减少数量

  minusCount(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    let num = +carts[index].num;
    if (num <= 1) {
      return false;
    }
    num = num - 1;
    carts[index].num = num;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'detailData',
      success: res => {
        console.log(res)
        this.setData({
          carts: res.data
        })
        wx.setTabBarBadge({
          index: 3,
          text: `${res.data.length}`
        })
      }
    })
  },
  // 单选
  selectList(e) {
    const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
    let carts = this.data.carts; // 获取购物车列表

    const selected = carts[index].selected; // 获取当前商品的选中状态
    carts[index].selected = !selected; // 改变状态
    this.setData({
      carts: carts
    });
    for (var i = 0; i < this.data.carts.length; i++) {
      // 当状态为全选时，每个元素其中有一个为false，则取消全选
      // 当状态为非全选时，每个元素都为true，则全选
      if (this.data.selectAllStatus) {
        if (!this.data.carts[i].selected) {
          this.setData({
            selectAllStatus: false
          });
          break;
        }
      } else {
        if (this.data.carts[i].selected) {
          this.setData({
            selectAllStatus: true
          });
        } else {
          this.setData({
            selectAllStatus: false
          });
          break;
        }
      }
    }

    this.getTotalPrice(); // 重新获取总价
  },
  // 全选
  selectAll(e) {
    console.log(e)
    let selectAllStatus = this.data.selectAllStatus; // 是否全选状态
    selectAllStatus = !selectAllStatus;
    let carts = this.data.carts;
    for (let i = 0; i < carts.length; i++) {
      carts[i].selected = selectAllStatus; // 改变所有商品状态
    }
    this.setData({
      selectAllStatus: selectAllStatus,
      carts: carts
    });

    // 改变全选状态

    this.getTotalPrice(); // 重新获取总价
  },
  //删除

  deleteList(e) {
    let that = this
    wx.showModal({
      title: '提示',
      content: '您确定删除吗',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          const index = e.currentTarget.dataset.index;
          // 删除购物车列表里这个商品
          wx.getStorage({
            key: 'detailData',
            success: res => {
              let _carts = res.data;
              console.log(res)
              _carts.splice(index, 1);
              wx.setStorage({
                data: _carts,
                key: 'detailData',
                success: res => {
                  that.setData({
                    carts: _carts

                  })
                  if (_carts.length === 0) {
                    wx.removeTabBarBadge({
                      index: 3,
                    })
                  } else {
                    wx.setTabBarBadge({
                      index: 3,
                      text: `${_carts.length}`
                    })
                  }
                }

              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },



  getTotalPrice() {
    let carts = this.data.carts; // 获取购物车列表
    let total = 0;
    for (let i = 0; i < carts.length; i++) { // 循环列表得到每个数据
      if (carts[i].selected) { // 判断选中才会计算价格
        total += carts[i].num * carts[i].price; // 所有价格加起来
      }
    }
    this.setData({ // 最后赋值到data中渲染到页面
      carts: carts,
      totalPrice: total.toFixed(2)
    });

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.getStorage({
      key: 'dataData',
      success: res => {
        wx.setTabBarBadge({
          index: 3,
          text: `${res.data.length}`
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
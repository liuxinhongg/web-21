//logs.js
const util = require('../../utils/util.js')
import $ from "../../utils/apiconfig"
import $$ from "../../utils/apiconfig"
Page({
  jumpsort(e){
    this.setData({
      name:e.currentTarget.dataset.name
    })
    // 导航跳转
    console.log(e.currentTarget.dataset)
    let sort = e.currentTarget.dataset.name;
    $.get('/goods/sortsearch',{sort},res=>{
      console.log(res);
      this.setData({
      sortsearchlist:res.data.data
    })
    })
  },
  jumpjump(e){
    console.log(e)
    console.log(e.currentTarget.dataset)
    this.setData({
      name:e.currentTarget.dataset.id
    })
    
    wx.navigateTo({
      url: '../details/details?info='+e.currentTarget.dataset.id,
    })
  },
  jumpen(a){
    console.log(a.currentTarget.dataset);
    this.setData({
      name:a.currentTarget.dataset.id
    })
    wx.navigateTo({
      url: '../sousuo/sousuo',
    })
  },
  data: {
    logs: [],
    bannerlist:[],
    sortlist:[],
    sortsearchlist:[]
  },
  onLoad: function (options) {
    $.get('/goods/sortsearch',{sort:"男装"},res=>{
      console.log(res);
      this.setData({
      sortsearchlist:res.data.data
    })
    })
    //轮播图
    $.get('/goods/banner',{},res=>{
      console.log(res);
      this.setData({
        bannerlist:res.data.data
      })
    })
    
    //分类
    $.get('/goods/sort',{},res=>{
      console.log(res);
      this.setData({
        sortlist:res.data.data
      })
    })

   //详情
    $.get('/goods/sortsearch',{},res=>{
      console.log(res);
      this.setData({
        sortsearchlist:res.data.data
      })
    })

    let that = this;
    wx.getLocation({
      success(res){
        that.setData({
          latitude:res.latitude,
          longitude:res.longitude,
          'markers[0].latitude':res.latitude,
          'markers[0].longitude':res.longitude,
        })
      }
    })
  },
  onReady: function () {
    this.audioCtx = wx.createAudioContext('myAudio');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

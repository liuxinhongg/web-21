// pages/person/person.js
const date = new Date()
const years = []
const months = []
const days = []
import $ from "../../utils/apiconfig"
for (let i = 1990; i <= date.getFullYear(); i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}

for (let i = 1; i <= 31; i++) {
  days.push(i)
}
Page({
  jumpsort(e) {
    console.log(e.currentTarget.dataset)
    this.setData({
      name: e.currentTarget.dataset.name
    })
    wx.navigateTo({
      url: '../user/user?info=' + e.currentTarget.dataset.name,
    })
  },
  jumpen(a) {
    console.log(a.currentTarget.dataset);
    this.setData({
      name: a.currentTarget.dataset.id
    })
    wx.navigateTo({
      url: '../sousuo/sousuo',
    })
  },
  jumpjump(e) {
    console.log(e)
    console.log(e.currentTarget.dataset)
    this.setData({
      name: e.currentTarget.dataset.id
    })

    wx.navigateTo({
      url: '../details/details?info=' + e.currentTarget.dataset.id,
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    latitude: '',
    longitude: '',
    markers: [{
      latitude: '',
      longitude: '',
      iconPath: '../../image/当前位置.png',
      width: 30,
      height: 30,
    }],
    longitude: 113.324520,
    focus: false,
    inputValue: '',
    years,
    year: date.getFullYear(),
    months,
    month: 2,
    days,
    day: 2,
    value: [9999, 1, 1],
    isDaytime: true,

    bannerlist: [],
    sortlist: [],
    sortsearchlist: [],
    sortsearchlists: []
  },
  audioPlay: function () {
    this.audioCtx.play()
  },
  audioPause: function () {
    this.audioCtx.pause()
  },
  audio14: function () {
    this.audioCtx.seek(14)
  },
  audioStart: function () {
    this.audioCtx.seek(0)
  },
  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  jump() {
    wx.navigateTo({
      url: '../index/index',
    })
  },
  // onShareAppMessage() {
  //   return {
  //     title: 'cover-view',
  //     path: 'page/component/pages/cover-view/cover-view'
  //   }
  // },
  bindChange(e) {
    const val = e.detail.value
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]],
      isDaytime: !val[3]
    })
  },
  btn() {
    this.setData({
      x: 30,
      y: 30
    })
  },

  onShareAppMessage() {
    return {
      title: 'checkbox',
      path: 'page/component/pages/checkbox/checkbox'
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'detailData',
      success: res => {
        wx.setTabBarBadge({
          index: 3,
          text: `${res.data.length}`
        })
      }
    })
    //轮播图
    $.get('/goods/banner', {}, res => {
      console.log(res);
      this.setData({
        bannerlist: res.data.data
      })
    })

    //分类
    $.get('/goods/sort', {}, res => {
      console.log(res);
      this.setData({
        sortlist: res.data.data
      })
    })

    //详情

    $.get('/goods/sortsearchs', {}, res => {
      console.log(res);
      this.setData({
        sortsearchlists: res.data.data
      })
    })


    let that = this;
    wx.getLocation({
      success(res) {
        that.setData({
          latitude: res.latitude,
          longitude: res.longitude,
          'markers[0].latitude': res.latitude,
          'markers[0].longitude': res.longitude,
        })
      }
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.audioCtx = wx.createAudioContext('myAudio');

    let context = wx.createCanvasContext('canvas');
    context.setStrokeStyle('yellow');
    context.setLineWidth(5);
    // 头
    context.moveTo(160, 100)
    context.arc(100, 100, 60, 0, 2 * Math.PI, true)
    //嘴
    context.moveTo(140, 100);
    context.arc(100, 100, 40, 0, Math.PI, false);
    //眼睛
    context.moveTo(85, 80);
    context.arc(80, 80, 5, 0, 2 * Math.PI, false);
    context.moveTo(125, 80);
    context.arc(120, 80, 5, 0, 2 * Math.PI, false);
    context.stroke();
    context.draw();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
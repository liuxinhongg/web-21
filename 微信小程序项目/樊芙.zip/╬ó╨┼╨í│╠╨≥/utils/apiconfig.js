const apiconfig = "http://localhost:3000";
let ajax = {
  //请求方式（地址，结果，成功函数）
  get(url,data,success){
    wx.request({
      url:apiconfig + url,
      data,
      method:'GET',
      success:success
    }) 
  },
  promiseGet(url,data,success){
    return new Promise((res,rej)=>{
      wx.request({
        url:apiconfig + url,
        data,
        success:res,
        fail:rej
      }) 
    })
}
}
export default ajax;






















































































































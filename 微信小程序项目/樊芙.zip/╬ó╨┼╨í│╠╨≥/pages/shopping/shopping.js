// pages/shopping/shopping.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    totalMoney:0,//总价为0
    allprice:0,
    status:"false",
    selectAllStatus:false,
    cartlist:[]
  },
  // 计算价格
  getTotalmoney(){
    let allprice = 0;
    let list = this.data.list;
    for(let i = 0;i< list.length;i++){
      console.log(list[i].status)
      if(list[i].status === "true"){
        allprice = allprice + this.data.list[i].price * this.data.list[i].num;
      }
    }
    this.setData({
      totalMoney:allprice
    })
  },
  // 加
jia(e){
  let arr = this.data.list;
  console.log(arr);
  let index = e.currentTarget.dataset.id;
  console.log(index);
  console.log(this.data.list);
  console.log(e);
  arr.forEach((item,num)=>{
    console.log(item);
    if(num === index){
      item.num = +item.num + 1
      this.setData({
        list:this.data.list
      })
    }
    this.getTotalmoney();
  })
},
// 减
jian(e){
  let arr = this.data.list;
  let index = e.currentTarget.dataset.id;
  arr.forEach((item,num)=>{
    console.log(num);
    console.log(item);
    if(num == index){
      if(item.num > 0){
        item.num = +item.num - 1
        this.setData({
          list:this.data.list
        })
      }
    }
    this.getTotalmoney(); 
  })
},
// 删除
del(e){
  console.log(e);
  let index = e.currentTarget.dataset.id;
  let list = this.data.list;
  list.splice(index,1);
  this.setData({
    list:list
  });
  // 删除stoStorage
  wx.setStorage({
    data: list,
    key: 'info',
  })
  if(!list.length){
    this.setData({
      haslist:false
    })
  }else{
    this.getTotalmoney();
  }
},
// 单选
jump(e){
  console.log(e);
  // console.log(e.currentTarget.dataset.info.price)
  // this.data.status = !this.data.status;
  this.setData({
    // status:!status
  })
  let list = this.data.list;
  let state = e.currentTarget.dataset.status;
  let index = e.currentTarget.dataset.index;
  console.log(list);
  console.log(this);
  this.getTotalmoney();
  list.forEach((item,num)=>{
    if(num === index){
      if(state=="false"){   
        list[num].status = "true"
        this.setData({
          list:this.data.list,
        })
        
      }else{
        list[num].status = "false"
        this.setData({
          list:this.data.list,
        })
        
      }
      this.getTotalmoney();


      if(list[num].status === "true") {
        this.data.cartlist.push(list[num].status);
      } else {
        this.data.cartlist.pop(list[num].status);
      }

    }
    
    console.log(this.data.cartlist)
    if(list.length == this.data.cartlist.length) {
      this.setData({
        status:"true",
      })
    } else {
      this.setData({
        status:"false",
      })
    }

  })


},
// 全选

jumpone(e){
console.log(e);
// let selectAllStatus = this.data.selectAllStatus;    // 是否全选状态
//     selectAllStatus = !selectAllStatus;
let list = this.data.list;
let index = e.currentTarget.dataset.index;
let state = e.currentTarget.dataset.status;
for (let i = 0; i < list.length; i++) {
  console.log(list[i].status)
  if(this.data.status === "false"){
    list[i].status = "true"
    this.setData({
      list:this.data.list,
    })    
  } else {
    list[i].status = "false"
    this.setData({
      list:this.data.list,
    })
  }
}


  this.getTotalmoney();
  if(state === "true"){
    this.setData({
      status:"false",
    })
  }else{
    this.setData({
      status:"true"
    })
  }                     

},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'info',
      success:(res)=>{
        console.log(res);
        this.setData({
          list:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
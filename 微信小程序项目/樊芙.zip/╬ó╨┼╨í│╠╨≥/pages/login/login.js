// pages/login/login.js
const app = getApp();
import $$ from '../../utils/apiconfig';
Page({
  data: {
    img: [],
    leftlist:[],
    rightlist:[],
    name:'',
    active:"active"
  },

  /**
   * 页面的初始数据
   */

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    this.getdata();
    this.sortdata(options.data);
  },
  jumpone(e){
    console.log(e.currentTarget.dataset.id);
    console.log(e);
   
    wx.navigateTo({
      url: '../details/details?id=' + e.currentTarget.dataset.id
    })
  },
  
  list(e){
    console.log(e);
    let name = e.currentTarget.dataset.name;
    this.setData({
      name:e.currentTarget.dataset.name
    })
    if(name){
      this.sortdata(name);
    }

    $$.promiseGet('/goods/sort2',{name}).then(res=>{
      console.log(res);
      this.setData({
        rightlist:res.data.data 
      })
    })
  },
  sortdata(val){
    $$.promiseGet("/goods/chaxun1",{sort:val}).then(res=>{
      console.log(res);
    })
  },
      getdata(name){
        console.log(name)
        $$.promiseGet('/goods/login',{}).then(res=>{
            console.log(res);
            this.setData({
              leftlist:res.data.data
            })
        })
      },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let name = app.globalData.name;
    console.log(app.globalData.name);
    $$.promiseGet('/goods/sort2',{name}).then(res=>{
      console.log(res);
      this.setData({
        rightlist:res.data.data
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
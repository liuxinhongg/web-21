// pages/page/page.js
const app = getApp();
const date = new Date()
const years = []
const months = []
const days = []

for (let i = 1990; i <= date.getFullYear(); i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}

for (let i = 1; i <= 31; i++) {
  days.push(i)
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    x:0,
    y:0,
    name:'',
    num:100,
    age:20,
    seen:false,
    msg:"马上就元旦了",
    years,
    year: date.getFullYear(),
    months,
    month: 2,
    days,
    day: 2,
    value: [9999, 1, 1],
    isDaytime: true,
    onShareAppMessage() {
      return {
        title: 'picker-view',
        path: 'page/component/pages/picker-view/picker-view'
      }
    },
    pome:[
      {title:"锦瑟无端五十弦，一线一柱思华年",id:1},
      {title:"庄生晓梦迷蝴蝶，望帝春心托杜鹃",id:2},
      {title:"沧海月明珠有泪，蓝田日暖玉生烟",id:3},
      {title:"此情可待成追忆，只是当时已惘然",id:4}
    ],
    poetry:[
      {name:"煮豆燃豆萁",id:1},
      {name:"豆在釜中泣",id:2},
      {name:"本是同根生",id:3},
      {name:"相煎何太急",id:4},
    ],
    item: {
      index: 0,
      msg: 'this is a template',
      time: '2016-09-15'
    },
    items: [
      {value: 'USA', name: '美国'},
      {value: 'CHN', name: '中国', checked: 'true'},
      {value: 'BRA', name: '巴西'},
      {value: 'JPN', name: '日本'},
      {value: 'ENG', name: '英国'},
      {value: 'FRA', name: '法国'}
    ],
    checkboxItems: [
      {name: 'USA', value: '美国'},
      {name: 'CHN', value: '中国', checked: 'true'}
    ],
    radioItems: [
      {name: 'USA', value: '美国'},
      {name: 'CHN', value: '中国', checked: 'true'}
    ],
    hidden: false,
    content: `<div><h4>在富文本中显示</h4></div>`
  },
  bindChange(e) {
    const val = e.detail.value
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]],
      isDaytime: !val[3]
    })
  },
  btnlist(e){
    // e(event) 是一个对象
    //获取输入框的value值
    console.log(e.detail.value);
  },
  jump(){
    //不能跳导航 navigateTo（关闭所有页面，只跳到当前页面）
      wx.navigateTo({
        url:"../index/index?name = yangxiaoling"
      })
  },
  btn(){
    // console.log(this);
    // setdata  数据的双向绑定  改变data里面的值，并映射到全局
    this.setData({
      x:30,
      y:30
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options);
    //   console.log(app.globalData.username);
    wx.request({
      url: "http:localhost:3000/goods/insert",
      method:"GET",
      success:res=>{
        console.log(res);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
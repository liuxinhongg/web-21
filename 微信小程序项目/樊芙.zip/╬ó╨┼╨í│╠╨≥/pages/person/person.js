// pages/person/person.js
const app = getApp();
import $$ from "../../utils/apiconfig";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    background: [
      // "../../image/1.jpg",
      // "../../image/2.jpg",
      // "../../image/3.jpg",
      // "../../image/4.jpg"
    ],
    title: [],
    recommen:[]
  },
  jumplist(e) {
    wx.setStorage({
      data: e.currentTarget.dataset.name,
      key: 'info',
      success: () => {
        wx.switchTab({
          url: "../login/login",
        })
      }
    })
    app.globalData.name = e.currentTarget.dataset.name;
  },
  jumpone(e){
    console.log(e.currentTarget.dataset.id);
    console.log(e);
    wx.navigateTo({
      url: '../details/details?id=' + e.currentTarget.dataset.id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 轮播图
    $$.promiseGet('/goods/login1', {}).then(res => {
        console.log(res);
        this.setData({
          background: res.data.data
        })
      })
      $$.get('/goods/login', {}, res => {
        console.log(res);
        this.setData({
          title: res.data.data
        })
      })
      $$.get('/goods/sort3', {}, res => {
        console.log(res);
        this.setData({
          recommen: res.data.data
        })
      })
    // 导航
    // wx.request({
    //   url: "http://192.168.1.109:3000/goods/login",
    //   method: "GET",
    //   success: res => {
    //     console.log(res);
    //     this.setData({
    //       title: res.data.data
    //     })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
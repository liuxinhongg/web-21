// pages/page/page.js
// const date = new Date();
// const years = [];
// const months = [];
// const days = [];
// for (let i = 1990; i <= date.getFullYear(); i++) {
//   years.push(i)
// }

// for (let i = 1; i <= 12; i++) {
//   months.push(i)
// }

// for (let i = 1; i <= 31; i++) {
//   days.push(i)
// }
//logs.js
// const util = require('../../utils/util.js')
// const app = getApp();
// const $ = require("../../utils/apiConfig")
import $ from"../../utils/apiConfig"
Page({
  data: {
   bannerlist:[],
   sort:[],
   sortimg:[],
   searchItem:[],
   loadingMore:false,
   loadingOver:false
  },
  jumplist(e){
    console.log(e);
    // 将数据存储在本地缓存中指定的 key 中
    wx.setStorage({ 
      data:e.currentTarget.dataset.name,
      key: 'info',
      // 数据储存成功之后发送ajax
      success:()=>{  
        wx.switchTab({  //跳转到 tabBar 页面
          url: '../sort/sort',
        })
      }
    })
    // app.globalData.name = e.currentTarget.dataset.name; //全局传参
  },
  // 跳转详情页传参
  contTap(e){
    // console.log(e.currentTarget.dataset.id);
    wx.navigateTo({
      url: '../details/details?id=' + e.currentTarget.dataset.id,
    })
  },

  onLoad: function (options) {
    // 导航
    // wx.request({
    //   url: 'http://192.168.1.106:3000/goods/fenlei',
    //   method:"GET",
    //   success:res=>{
    //     console.log(res);
    //     this.setData({
    //      sort:res.data.data,
    //      sortimg:res.data.data
    //     })
    //   }
    // }),
    $.get('/goods/fenlei',{},res=>{
      // console.log(this)
      this.setData({
         sort:res.data.data,
         sortimg:res.data.data
        })
    }),
    // 轮播图
    $.get('/goods/bout',{},res=>{
      // console.log(res)
      this.setData({
         bannerlist:res.data.data
        })
      
    }),
    $.promiseGet('/goods/sort-search', {}).then(res => {
      // console.log(res)
      this.setData({  //函数用于将逻辑层数据发送到视图层
        searchItem: res.data.data,
      })
    })

    // wx.request({
    //   url: 'http://192.168.1.106:3000/goods/bout',
    //   method:"GET",
    //   success:res=>{
    //     console.log(res);
    //     this.setData({
    //      bannerlist:res.data.data
    //     })
    //   }
    // })
    wx.getStorage({
      key: 'name',
      // 发送ajax
      success: (res) => {
        console.log(res.data)
        if(res.data.length !== 0){
          wx.setTabBarBadge({
            index:2, //tabBar 的哪一项，从左边算起
            text:`${res.data.length}`
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      loadingMore:true,
      loadingOver:false,
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  
})



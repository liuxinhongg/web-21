const app = getApp();
import $$ from "../../utils/apiConfig"
Page({
  data: {
    sort: [],
    sortsearch: [],
    currentIndex: 0,
    name:"男装"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    // 左侧导航
    // wx.request({
    //   url: 'http://192.168.1.106:3000/goods/fenlei',
    //   method:"GET",
    //   success:res=>{
    //     console.log(res);
    //     this.setData({
    //      sort:res.data.data
    //     })
    //   }
    // }),
    $$.promiseGet('/goods/fenlei', {}).then(res => {
        // console.log(this)
        this.setData({  //函数用于将逻辑层数据发送到视图层
          sort: res.data.data,
        })
      })
      // 构造右侧商品数据
      // wx.request({
      //   url: 'http://192.168.1.106:3000/goods/sortsearch',
      //   data:{sort:"男装"},
      //   method:"GET",
      //   success:res=>{
      //     console.log(res);
      //     this.setData({
      //      sortsearch:res.data.data
      //     })
      //     console.log(this.data.sortsearch)
      //   }
      // })
      // $$.promiseGet('/goods/sortsearch', {
      //   sort: "男装"
      // }).then(res => {
      //   this.setData({
      //     sortsearch: res.data.data
      //   })
      // })
  },

  switchleftTap(e) {
    // console.log(e);

    $$.promiseGet('/goods/sortsearch', {
      sort: e.currentTarget.dataset.name
    }).then(res => {
      this.setData({
        sortsearch: res.data.data,
        name:e.currentTarget.dataset.name
      })
    })
    // wx.setStorage({
    //   key: 'info',
    //   data:e.currentTarget.dataset.name,
    // })
  },
  // 跳转详情页面传参
  contTap(e){
      // console.log(e.currentTarget.dataset.id);
      wx.navigateTo({
        url: '../details/details?id=' + e.currentTarget.dataset.id,
      })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 获取储存的数据
    wx.getStorage({
      key: 'info',
      // 发送ajax
      success: (res) => {
        // console.log(res)
        const aa = res; //将获取的数据储存起来
        $$.promiseGet('/goods/sortsearch', {  //请求数据
          sort: res.data   //获取对应的分类数据
        }).then(res => {
          // console.log(res)
          this.setData({
            sortsearch: res.data.data,
            name:aa.data 
          })
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
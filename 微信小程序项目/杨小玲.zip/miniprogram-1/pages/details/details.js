const app = getApp();
import $$ from "../../utils/apiConfig"
Page({
  data: {
    isLike: true,
    detailTap:[],
    cartdata:[],
    // banner
    // imgUrls: [
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   ":https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp"
    // ],
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动切换
    interval: 3000, //自动切换时间间隔,3s
    duration: 1000, //  滑动动画时长1s

    // 商品详情介绍
    // detailImg: [
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    //   "https://img13.360buyimg.com/babel/s120x120_jfs/t1/170688/5/910/107237/5ff2c800E631b2b75/e11e1675b223c2c4.jpg!cc_120x120.webp",
    // ],

  },
  //预览图片
  previewImage: function (e) {
    var current = e.target.dataset.src;

    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls: this.data.imgUrls // 需要预览的图片http链接列表  
    })
  },
  // 收藏
  addLike() {
    this.setData({
      isLike: !this.data.isLike
    });
  },
  // 跳到购物车
  toCar(e) {
    wx.switchTab({
      url: '../cart/cart'
    })
  },
  addCar(e){
    // console.log(e.currentTarget.dataset.info)
    // console.log(e)
    // console.log(this)
   
   
    let datalist = this.data.cartdata || [];
    // console.log(e.target.dataset.info[0])
    let obj = {
      in:e.target.dataset.info[0]
    }
    datalist.push(obj);
    wx.setStorage({ 
      data:datalist,
      key:'name',
      // 数据储存成功之后发送ajax
      success:()=>{  
        wx.showLoading({
          title: '加载中',
          success:res=>{
     
            setTimeout(function () {
              wx.hideLoading()
              wx.switchTab({  //跳转到 cart 页面
                url:"../cart/cart",
                })
            }, 500)
          }
        })
      }
    })
  },
  // 立即购买
  immeBuy() {
    wx.showToast({
      title: '购买成功',
      icon: 'success',
      duration: 2000
    });
  },
  onLoad: function (options){
    // 渲染传过来的参数
    $$.promiseGet("/goods/has_id",{sort:options.id}).then(res=>{
      // console.log(res)
      this.setData({
        detailTap:res.data.data
      });
      // console.log(res);
    })
    wx.getStorage({
      key: 'name',
      // 发送ajax
      success: (res) => {
        // console.log(res)
          this.setData({
            cartdata: res.data,
          })
      }
    })
  },
  
})
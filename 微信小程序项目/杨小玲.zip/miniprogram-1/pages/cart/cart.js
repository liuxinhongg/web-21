const app = getApp();
import $$ from "../../utils/apiConfig"
Page({
  data: {
    isAllSelect: false,
    totalMoney: 0, //总价为零
    minusStatus: true,
    carts: [],
    hasList: false, // 列表是否有数据
    selectAllStatus: false, //全选状态
    aAllprice: 0
  },
  /**
   * 计算价格
   */
  getTtotalMoney() {
    let aAllprice = 0;
    let carts = this.data.carts;
    //得知是否全选
    for (let i = 0; i < carts.length; i++) {
      if (carts[i].isSelect) {
        aAllprice = aAllprice + this.data.carts[i].in.price * this.data.carts[i].in.num;
      }
    }
    this.setData({
      totalMoney: aAllprice
    })
  },

  // 点击选中
  switchSelect(e) {
    let selectAllStatus = this.data.selectAllStatus; //全选状态
    const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
    let carts = this.data.carts;
    let isSelect = carts[index].isSelect; //获取当前商品的选中状态
    carts[index].isSelect = !isSelect; // 改变状态
    // 合计
    this.getTtotalMoney();
    //得知是否全选
    let a = true;
    carts.forEach(item => {
      item.isSelect === false ? a = false : "";
    })

    a ? selectAllStatus = true : selectAllStatus = false;

    this.setData({
      carts: carts,
      selectAllStatus: selectAllStatus,
    });
  },

  // 增加数量
  addCount(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    carts[index].in.num = carts[index].in.num + 1;

    this.setData({
      carts: carts,
    })
    this.getTtotalMoney();
  },

  // 减少数量
  minusCount(e) {
    console.log(e)
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    carts[index].in.num = carts[index].in.num - 1;
    if (carts[index].in.num < 1) {
      wx.showToast({
        title: '宝贝不能再减少啦',
        icon: 'none'
      })
      carts[index].in.num = 1;
      // return false;
    } else {
      this.setData({
        carts: carts,
      })
      this.getTtotalMoney();
    }

  },

  // 全选事件
  allSelect(e) {
    let selectAllStatus = this.data.selectAllStatus; // 是否全选状态
    selectAllStatus = !selectAllStatus;
    let carts = this.data.carts;
    if (!this.data.selectAllStatus) {
      for (let i = 0; i < carts.length; i++) {
        carts[i].isSelect = true
      }
    } else {
      for (let i = 0; i < carts.length; i++) {
        carts[i].isSelect = false
      }
    }
    this.setData({
      selectAllStatus: selectAllStatus,

      carts: carts
    });
    this.getTtotalMoney(); // 重新获取总价
  },

  //删除商品
  deleteList(e) {
    const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
    let carts = this.data.carts;
    let that = this;
   
    wx.showModal({
      title: '提示',
      content: '确定删除此商品',
      success (res) {
        if (res.confirm) {
            console.log('用户点击确定')
            carts.splice(index, 1); // 删除购物车列表里这个商品
            that.setData({
              carts: carts
            });
            wx.setStorage({
              key: "name",
              data: carts,
            })
            // 如果购物车为空，删除右上角添加文本
            if (carts.length === 0) {
              wx.removeTabBarBadge({
                index: 2
              })
            } else {
              // 设置右上角添加文本
              wx.setTabBarBadge({
                index: 2, //tabBar 的哪一项，从左边算起
                text: `${carts.length}`
              })
            }
            if (!carts.length) { // 如果购物车为空
              that.setData({
                hasList: false // 修改标识为false，显示购物车为空页面
              });
          } else {
            that.getTtotalMoney() //重新计算价格
            }
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

    
    

    // wx.showToast({
    //   title: '已删除',
    //   icon: 'success',
    // });

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 获取储存的数据
    wx.getStorage({
      key: 'name',
      // 发送ajax
      success: (res) => {
        
        res.data.forEach(item => {
          item.isSelect = false;
        })
        this.setData({
          carts: res.data
        })
        if (res.data.length === 0) {
          wx.removeTabBarBadge({
            index: 2
          })
        }else{
           wx.setTabBarBadge({
          index: 2, //tabBar 的哪一项，从左边算起
          text: `${res.data.length}`
        })
        }
       
      }
    })
  }


})
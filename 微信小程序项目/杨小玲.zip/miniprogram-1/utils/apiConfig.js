const apiConfig = 'http://localhost:3000';

let ajax = {
  get(url,data,success){
    wx.request({
      url:apiConfig+url,
      data,
      method:'get',
      success,
    })
  },
  promiseGet(url,data){
    return new Promise((resolve,reject)=>{
      wx.request({
        url:apiConfig+url,
        data,
        success:resolve,
        fail:reject
      })
    })
  }
}
export default ajax
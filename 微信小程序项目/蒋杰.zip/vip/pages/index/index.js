//index.js
//获取应用实例
const app = getApp()
import $ from "../../utils/apiconfig"
Page({
  data: {
    // motto: 'Hello World',
    // userInfo: {},
    // hasUserInfo: false,
    // canIUse: wx.canIUse('button.open-type.getUserInfo'),
    banner:[],
    sort:[],
    sortsearchcha:[],
    name:''
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  jump(e){
    app.globalData.a = e.currentTarget.dataset.name;
    console.log(app.globalData.a)
    wx.navigateTo({
      url: '../content/content',
    })
  },
  ss(e){
    app.globalData.a = e.detail.value
    wx.navigateTo({
      url: '../content/content',
    })
  },
  content(e){
    // app.globalData.b = e.currentTarget.dataset.id
    // this.setData({
    //   name:e.currentTarget.dataset.id
    // })
    wx.navigateTo({
      url: '../ent/ent?info='+e.currentTarget.dataset.id,
    })
  },
  onLoad: function () {
    wx.getStorage({
      key: 'if',
      success: res => {
        if(res.data.length !==0){
          wx.setTabBarBadge({
            index: 2,
            text: `${res.data.length}`
          })
        }
      }
    })
  },
  onReady:function(){
    $.get("/goods/bannerchaxun",{},res=>{
      this.setData({
        banner:res.data.data
        })
    })
    $.get("/goods/sortchaxun",{},res=>{
      this.setData({
        sort:res.data.data
        })
    })
    $.get("/goods/sortsearchcha",{},res=>{
      this.setData({
        sortsearchcha:res.data.data
        })
    })
  },

})

// pages/ent/ent.js
const util = require('../../utils/util.js')
import $ from "../../utils/apiconfig"
const app = getApp()
Page({
  data: {
    sortid:[],
    name:'',
    dataList:[],
    other:[]
  },
  shop(e){
    // app.globalData.b.push(this.data.sortid[0])
    console.log(e)
    let data = e.currentTarget.dataset.obj[0];
    let dataList = this.data.other || [];
    dataList.push(data);
    wx.setStorage({
      data: dataList,
      key: 'if',
    })
    wx.showLoading({
      title: '加载中',
      success:res=>{
        setTimeout(function () {
          wx.hideLoading()
          wx.switchTab({
            url: '../shop/shop'
          })
        }, 500)
      }

    })
  },
  gwc(e){
    wx.switchTab({
      url: '../shop/shop'
    })
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = options.info
    $.promiseGet(`/goods/sortid`, {id:that}).then(res => {
      this.setData({
        sortid: res.data.data
      })
    })
    wx.getStorage({
      key: 'if',
      success:res=>{
        console.log(res);
        this.setData({
          other:res.data
        })
       
      
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
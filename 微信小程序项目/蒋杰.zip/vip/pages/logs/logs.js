const util = require('../../utils/util.js')
import $ from "../../utils/apiconfig"
const app = getApp()
Page({
  data: {
   sort:[],
   sortsearch:[],
   banner:[],
   name:''
  },
  onLoad: function () {
  
  },
  jumpp(e){
   this.setData({
     name:e.currentTarget.dataset.name
   })
   wx.setStorage({
     data: e.currentTarget.dataset.name,
     key: 'info',
    success:res=>{
     this.ajax(e.currentTarget.dataset.name)
    }
   })
  },
  jump(e){
    wx.navigateTo({
      url: '../sousuo/sousuo',
    })
  },
  content(e){
    this.setData({
      name:e.currentTarget.dataset.id
    })
    wx.navigateTo({
      url: '../ent/ent?info='+e.currentTarget.dataset.id,
    })
  },
  ajax(sort){
    $.promiseGet(`/goods/cha?sort=${sort}`, {}).then(res => {
      this.setData({
        sortsearch: res.data.data
      })
    })
  },
 
  onReady:function(){
    $.get("/goods/sortchaxun",{},res=>{
      this.setData({
        sort:res.data.data
        })
    })
    $.get("/goods/bannerchaxun",{},res=>{
      this.setData({
        banner:res.data.data
        })
    })
    this.ajax("男装")
  },
  onShow:function(){
    // this.ajax(e.currentTarget.dataset.name)
  }
})

// pages/shop/shop.js
const app = getApp()
import $ from "../../utils/apiconfig"
Page({
  /**
   * 页面的初始数据
   */
  data: {
    sortid: [],
    price: 0,
    status: 'false'
  },
  // 购物车跳详情
  content(e) {
    wx.navigateTo({
      url: '../ent/ent?info=' + e.currentTarget.dataset.id,
    })
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
   // 删除
   delete(e) {
    let that = this
    wx.showModal({
      title: '提示',
      content: '您确定删除吗',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          let index = e.currentTarget.dataset.index
          wx.getStorage({
            key: 'if',
            success: res => {
              let data = res.data
              data.splice(index, 1);
              wx.setStorage({
                data: data,
                key: 'if',
                success: () => {
                 that.setData({
                   sortid:data
                 })
                 if(data.length===0){
                   wx.removeTabBarBadge({
                     index: 2,
                   })
                   
                 }else{
                  wx.setTabBarBadge({
                    index: 2,
                    text: `${data.length}`
                  })
                 }
                }
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  // 单选
  click(e) {
    let index = e.currentTarget.dataset.index
    let _sortid = this.data.sortid
    _sortid[index].status = _sortid[index].status === 'false' ? "true" : "false";
    let _true = 'true';
    _sortid.forEach(item => {
      item.status === 'false' ? _true = 'false' : "";
    })
    this.setData({
      status: _true,
      sortid: _sortid
    })
    this.total()
  },
  // 全选
  choice(e) {
    let _true = this.data.status;
    let _sortid = this.data.sortid;
    _true = _true === "false" ? "true" : "false";
    _sortid.forEach(item => {
      item.status = _true
    })
    this.setData({
      status: _true,
      sortid: _sortid
    })
    this.total()
  },
  // 减
  jian(e) {
    let id = e.currentTarget.dataset.id
    let _sortid = this.data.sortid
    _sortid.forEach(item => {
      if (item.id === id) {
        item.num = item.num <= 1 ? 1 : item.num - 1
      }
    })
    this.setData({
      sortid: _sortid
    })
    this.total()
  },
  // 加
  jia(e) {
    let id = e.currentTarget.dataset.id
    let _sortid = this.data.sortid
    _sortid.forEach(item => {
      if (item.id === id) {
        item.num++
      }
    })
    this.setData({
      sortid: _sortid
    })
    this.total()
  },
  total() {
    let _price = 0
    let _sortid = this.data.sortid
    _sortid.forEach(item => {
      if (item.status === 'true') {
        _price += item.num * item.price
      }
    })
    this.setData({
      price: _price
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 存在app拿出来
    // let that = app.globalData.b
    // this.setData({
    //   sortid: that
    // })
    // 存在storage拿出来
    wx.getStorage({
      key: 'if',
      success: res => {
        this.setData({
          sortid: res.data
        })
        if(res.data.length !==0){
          wx.setTabBarBadge({
            index: 2,
            text: `${res.data.length}`
          })
        }
      }
    })
  },
})
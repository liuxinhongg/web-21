// pages/person/person.js
const app = getApp()
import $ from "../../utils/apiconfig"
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    sort:[]
  },
  content(e){
    wx.navigateTo({
      url: '../ent/ent?info='+e.currentTarget.dataset.id,
    })
  },
  getUserInfo: function(e) {
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    $.get("/goods/sortchaxun",{},res=>{
      this.setData({
        sort:res.data.data
        })
    })
  },
})
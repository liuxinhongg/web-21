const apiconfig = "http://localhost:3000";
let ajax = {
  get(url,data,success){
    wx.request({
      url: apiconfig+url,
      data,
      method:"GET",
      success,
    })
  },
  promiseGet(url,data,success){
    return new Promise((res,rej)=>{
      wx.request({
        url: apiconfig+url,
        data,
        success:res,
        fail:rej
      })
    })
  }
}
export default ajax